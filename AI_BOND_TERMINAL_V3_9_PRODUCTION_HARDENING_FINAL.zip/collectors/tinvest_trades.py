from database.db import SessionLocal
from database.models import Trade

class TInvestTradeCollector:
    def __init__(self,client): self.client=client
    def collect_orders(self,account_id):
        orders=self.client.orders() if getattr(self.client,'account_id',None)==account_id else self.client.orders()
        with SessionLocal() as s:
            for o in orders.get('orders',[]) if isinstance(orders,dict) else (orders or []):
                oid=str(o.get('orderId',o.get('order_id',o.get('id',''))))
                if not oid: continue
                s.add(Trade(order_id=oid,account_id=account_id,isin=str(o.get('instrumentUid',o.get('instrumentId',''))),side=str(o.get('direction','')),price=self._price(o),quantity=self._int(o,'lotsExecuted','quantity'),status=str(o.get('status',''))))
            s.commit()
        return orders
    def collect_portfolio(self,account_id): return self.client.portfolio()
    @staticmethod
    def _int(o,*ks):
        for k in ks:
            if k in o: 
                try:return int(o[k])
                except:return None
        return None
    @staticmethod
    def _price(o):
        v=o.get('price');
        if isinstance(v,dict): return float(v.get('units',0))+float(v.get('nano',0))/1e9
        try:return float(v) if v is not None else None
        except:return None

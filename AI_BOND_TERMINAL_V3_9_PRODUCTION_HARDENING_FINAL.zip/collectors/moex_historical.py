from data.moex_real_collector import MOEXRealDataCollector
from database.db import SessionLocal
from database.models import BondPrice
from sqlalchemy import select
import pandas as pd

class MOEXHistoricalCollector(MOEXRealDataCollector):
    """Backward-compatible collector backed by the real MOEX ISS API."""
    def candles(self,secid,date_from=None,date_till=None,interval=24,board='TQCB'):
        if interval==24:
            return self.history(secid,board,date_from,date_till)
        url=f'{self.base}/engines/stock/markets/bonds/boards/{board}/securities/{secid}/candles.json'; payload=self._get(url,{'interval':interval,**({'from':date_from} if date_from else {}),**({'till':date_till} if date_till else {})}); b=payload.get('candles',{}); return pd.DataFrame(b.get('data',[]),columns=b.get('columns',[]))
    def persist(self,isin,df):
        if df.empty:return 0
        with SessionLocal() as s:
            n=0
            for _,r in df.iterrows():
                raw=r.get('begin') or r.get('TRADEDATE')
                if pd.isna(raw): continue
                ts=pd.to_datetime(raw).to_pydatetime(); exists=s.scalar(select(BondPrice).where(BondPrice.isin==isin,BondPrice.ts==ts))
                if exists: continue
                s.add(BondPrice(isin=isin,ts=ts,price=self._num(r,'close') or self._num(r,'LASTPRICE'),volume=self._num(r,'value') or self._num(r,'VALUE'),ytm=self._num(r,'yield') or self._num(r,'YIELD'))); n+=1
            s.commit(); return n
    @staticmethod
    def _num(r,k):
        try:
            v=r.get(k); return None if v is None or pd.isna(v) else float(v)
        except:return None
    def collect_and_persist(self,isin,date_from=None,date_till=None,board='TQCB'):
        df=self.candles(isin,date_from,date_till,24,board); return {'rows':len(df),'inserted':self.persist(isin,df),'source':'MOEX ISS'}

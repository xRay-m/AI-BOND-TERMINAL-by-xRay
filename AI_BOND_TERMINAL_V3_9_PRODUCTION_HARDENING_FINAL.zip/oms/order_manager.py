from dataclasses import dataclass,field
from datetime import datetime,timezone
import uuid
@dataclass
class Order:
    instrument_id:str; side:str; quantity:int; price:float|None; order_type:str='LIMIT'; client_id:str=field(default_factory=lambda:uuid.uuid4().hex); status:str='CREATED'; created_at:str=field(default_factory=lambda:datetime.now(timezone.utc).isoformat())
class OMS:
    TERMINAL={'FILLED','CANCELLED','REJECTED'}
    def __init__(self,broker): self.broker=broker; self.orders={}
    def create(self,**kw): o=Order(**kw); self.orders[o.client_id]=o; return o
    def submit(self,client_id,account_id,live=False):
        if not live: raise PermissionError('LIVE flag required')
        o=self.orders[client_id]; o.status='SUBMITTED'; return self.broker.post_order(o,account_id)
    def cancel(self,client_id,account_id): return self.broker.cancel_order(self.orders[client_id],account_id)

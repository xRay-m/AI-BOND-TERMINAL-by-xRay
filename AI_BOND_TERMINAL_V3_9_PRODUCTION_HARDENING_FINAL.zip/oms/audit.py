from pathlib import Path
import json, datetime, hashlib, threading

class AuditLog:
    """Append-only tamper-evident audit log using a SHA-256 hash chain."""
    def __init__(self,path='runtime/audit/audit.jsonl'):
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True); self.lock=threading.RLock()
    def _last_hash(self):
        if not self.path.exists(): return 'GENESIS'
        try:
            for line in reversed(self.path.read_text(encoding='utf8').splitlines()):
                if line.strip(): return json.loads(line).get('hash','GENESIS')
        except Exception: pass
        return 'GENESIS'
    def write(self,event,**payload):
        with self.lock:
            row={'ts':datetime.datetime.now(datetime.timezone.utc).isoformat(),'event':event,**payload}; row['prev_hash']=self._last_hash(); raw=json.dumps(row,ensure_ascii=False,sort_keys=True,default=str).encode(); row['hash']=hashlib.sha256(raw).hexdigest()
            with self.path.open('a',encoding='utf8') as f:f.write(json.dumps(row,ensure_ascii=False,sort_keys=True,default=str)+'\n')
            try:
                from database.service import write_audit; write_audit(event,row)
            except Exception: pass
            return row
    def read(self,limit=500):
        if not self.path.exists(): return []
        rows=[]
        for line in self.path.read_text(encoding='utf8').splitlines()[-limit:]:
            try: rows.append(json.loads(line))
            except: pass
        return rows
    def verify(self):
        prev='GENESIS'; count=0
        if not self.path.exists(): return {'ok':True,'rows':0,'reason':'empty'}
        for line in self.path.read_text(encoding='utf8').splitlines():
            if not line.strip(): continue
            row=json.loads(line); supplied=row.pop('hash',None); expected=hashlib.sha256(json.dumps(row,ensure_ascii=False,sort_keys=True,default=str).encode()).hexdigest()
            if row.get('prev_hash')!=prev or supplied!=expected: return {'ok':False,'rows':count,'error':'hash_chain_break'}
            prev=supplied; count+=1
        return {'ok':True,'rows':count,'head_hash':prev}

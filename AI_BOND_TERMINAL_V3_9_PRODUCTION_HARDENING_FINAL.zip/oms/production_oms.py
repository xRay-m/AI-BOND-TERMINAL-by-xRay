from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from trading.execution_journal import record as execution_record
import json, os, threading, uuid

TERMINAL={"FILLED","REJECTED","CANCELLED"}
@dataclass
class OMSOrder:
    client_id:str; instrument_id:str; side:str; quantity:int; price:float|None; order_type:str
    status:str="CREATED"; broker_order_id:str|None=None; created_at:str=""
    updated_at:str=""
    def touch(self): self.updated_at=datetime.now(timezone.utc).isoformat()

class ProductionOMS:
    """Idempotent OMS state machine. Broker adapter must expose post_order/order_state/cancel_order."""
    def __init__(self, broker, audit=None, state_path="data/orders.json"):
        self.broker=broker; self.audit=audit; self.state_path=state_path; self.lock=threading.RLock(); self.orders={}; self._load()
    def _load(self):
        try:
            data=json.loads(open(self.state_path,encoding='utf-8').read())
            for k,v in data.items(): self.orders[k]=OMSOrder(**v)
        except FileNotFoundError: pass
    def _save(self):
        os.makedirs(os.path.dirname(self.state_path) or '.',exist_ok=True)
        with open(self.state_path,'w',encoding='utf-8') as f: json.dump({k:asdict(v) for k,v in self.orders.items()},f,ensure_ascii=False,indent=2)
    def create(self,instrument_id,side,quantity,price,order_type="ORDER_TYPE_LIMIT"):
        with self.lock:
            cid=uuid.uuid4().hex; o=OMSOrder(cid,instrument_id,side,int(quantity),price,order_type,created_at=datetime.now(timezone.utc).isoformat()); o.touch(); self.orders[cid]=o; self._save(); execution_record('ORDER_CREATED',client_id=cid,instrument_id=instrument_id,side=side,quantity=quantity,price=price,order_type=order_type); return o
    def submit(self,cid):
        with self.lock:
            o=self.orders[cid]
            if o.status not in {"CREATED","RETRYABLE"}: return o
            direction="ORDER_DIRECTION_BUY" if o.side.upper()=="BUY" else "ORDER_DIRECTION_SELL"
            r=self.broker.post_order(o.instrument_id,o.quantity,direction,o.price,o.order_type)
            o.broker_order_id=r.get("orderId") or r.get("order_id") or r.get("orderRequestId") or r.get("order_request_id")
            o.status=r.get("executionReportStatus") or r.get("execution_report_status") or "SUBMITTED"; o.touch(); self._save(); return o
    def refresh(self,cid):
        with self.lock:
            o=self.orders[cid]
            if not o.broker_order_id: return o
            r=self.broker.order_state(o.broker_order_id)
            o.status=r.get("executionReportStatus") or r.get("execution_report_status") or r.get("status") or o.status; o.touch(); self._save(); return o
    def cancel(self,cid):
        with self.lock:
            o=self.orders[cid]
            if o.broker_order_id: self.broker.cancel_order(o.broker_order_id)
            o.status="CANCELLED"; o.touch(); self._save(); execution_record('ORDER_CANCELLED',client_id=cid,broker_order_id=o.broker_order_id); return o

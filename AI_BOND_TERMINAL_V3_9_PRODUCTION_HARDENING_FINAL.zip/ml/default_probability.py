from dataclasses import dataclass
import joblib
from ml.pd_pipeline import PDPipeline
@dataclass
class PDModel:
    model: object=None; trained: bool=False; metrics: dict=None
    def __post_init__(self): self.metrics=self.metrics or {}
    def fit(self,df,target='default_12m'):
        p=PDPipeline(); p.fit(df,target); self.model=p; self.trained=True; self.metrics=p.validate(df,target); return self
    def predict(self,df):
        if not self.trained:raise RuntimeError('PD model is not trained')
        return self.model.predict_proba(df)
    def save(self,path): joblib.dump(self.model.model if hasattr(self.model,'model') else self.model,path)
    @classmethod
    def load(cls,path):
        p=PDPipeline.load(path); return cls(p,True,{})

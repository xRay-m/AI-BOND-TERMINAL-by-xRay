from pathlib import Path
import joblib,numpy as np
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score,brier_score_loss
from ml.features import FEATURES,build_features
class PDPipeline:
    def __init__(self,features=None,model_path='models/pd_model.joblib'):
        self.features=features or FEATURES; self.model_path=Path(model_path)
        self.model=Pipeline([('imputer',SimpleImputer(strategy='median',add_indicator=True)),('scale',StandardScaler()),('clf',LogisticRegression(max_iter=3000,class_weight='balanced'))])
    def fit(self,df,target='default_12m'):
        d=build_features(df); target='default_12m' if target not in d.columns and 'default' in d.columns else target; X=d[self.features].replace([np.inf,-np.inf],np.nan); y=d[target].astype(int)
        if y.nunique()<2:raise ValueError('Target must contain both 0 and 1 classes.')
        self.model.fit(X,y); self.model_path.parent.mkdir(parents=True,exist_ok=True); joblib.dump({'model':self.model,'features':self.features},self.model_path); return self
    def validate(self,df,target='default_12m'):
        d=build_features(df); target='default_12m' if target not in d.columns and 'default' in d.columns else target; X=d[self.features].replace([np.inf,-np.inf],np.nan); y=d[target].astype(int); p=self.model.predict_proba(X)[:,1]
        return {'roc_auc':float(roc_auc_score(y,p)) if y.nunique()>1 else None,'brier':float(brier_score_loss(y,p)),'rows':len(d),'positive_rate':float(y.mean())}
    def predict_proba(self,df):
        d=build_features(df); return self.model.predict_proba(d[self.features].replace([np.inf,-np.inf],np.nan))[:,1]
    @classmethod
    def load(cls,path):
        o=joblib.load(path); x=cls(o['features'],path); x.model=o['model']; return x

import argparse,pandas as pd
from ml.pd_pipeline import PDPipeline
p=argparse.ArgumentParser(); p.add_argument('--csv',required=True); p.add_argument('--target',default='default_12m'); p.add_argument('--model',default='models/pd_model.joblib'); a=p.parse_args()
df=pd.read_csv(a.csv); m=PDPipeline(model_path=a.model).fit(df,a.target); print(m.validate(df,a.target))

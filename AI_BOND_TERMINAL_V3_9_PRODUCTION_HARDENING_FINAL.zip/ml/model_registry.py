from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import json, shutil

class ModelRegistry:
    """Local model registry with immutable version manifests and promotion states."""
    STATES = {"TRAINING", "VALIDATION", "PRODUCTION", "RETIRED", "FAILED"}
    def __init__(self, root='models/registry'):
        self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True)
        self.manifest=self.root/'registry.json'
        if not self.manifest.exists(): self.manifest.write_text(json.dumps({'models':[]},ensure_ascii=False,indent=2),encoding='utf-8')
    def _load(self):
        try:return json.loads(self.manifest.read_text(encoding='utf-8'))
        except:return {'models':[]}
    def _save(self,d): self.manifest.write_text(json.dumps(d,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
    def register(self,name,version,artifact_path,metrics,dataset,features,stage='VALIDATION',metadata=None):
        if stage not in self.STATES: raise ValueError(stage)
        p=Path(artifact_path); d=self._load(); item={
            'name':name,'version':version,'artifact':str(p),'metrics':metrics or {},'dataset':dataset or {},
            'features':list(features or []),'stage':stage,'registered_at':datetime.now(timezone.utc).isoformat(),
            'metadata':metadata or {},'immutable':True}
        d['models']=[x for x in d.get('models',[]) if not (x.get('name')==name and x.get('version')==version)] + [item]
        self._save(d); return item
    def promote(self,name,version,stage='PRODUCTION'):
        if stage not in self.STATES: raise ValueError(stage)
        d=self._load(); found=False
        for x in d['models']:
            if x.get('name')==name and x.get('version')==version: x['stage']=stage; x['promoted_at']=datetime.now(timezone.utc).isoformat(); found=True
            elif x.get('name')==name and stage=='PRODUCTION' and x.get('stage')=='PRODUCTION': x['stage']='RETIRED'
        if not found: raise KeyError(f'{name}:{version}')
        self._save(d); return self.get(name,version)
    def get(self,name,version=None):
        xs=[x for x in self._load().get('models',[]) if x.get('name')==name]
        if version: return next((x for x in xs if x.get('version')==version),None)
        return next((x for x in reversed(xs) if x.get('stage')=='PRODUCTION'), xs[-1] if xs else None)
    def list(self): return self._load().get('models',[])

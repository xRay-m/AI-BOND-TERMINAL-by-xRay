import numpy as np, pandas as pd

ALIASES={'duration_years':'duration','bond_yield_pct':'ytm_pct','bond_yield':'ytm_pct','default_12m':'defaulted','default':'default_12m','debt_service_coverage':'dscr'}
FEATURES=['ytm_pct','price_pct','coupon_pct','days_to_maturity','duration','volume_rub','volatility','debt_to_ebitda','interest_coverage','current_ratio','rating_numeric','liquidity_score','spread_bps','revenue_growth','ebitda_margin','debt_service_coverage']

def build_features(df):
    d=df.copy()
    for a,b in ALIASES.items():
        if a in d and b not in d:d[b]=d[a]
    for c in FEATURES+['price','nominal','close','maturity']:
        if c in d and c!='maturity':d[c]=pd.to_numeric(d[c],errors='coerce')
    if 'price_pct' not in d:d['price_pct']=d.get('price',np.nan)/d.get('nominal',1000)*100
    if 'days_to_maturity' not in d:d['days_to_maturity']=np.nan
    if 'maturity' in d and d['days_to_maturity'].isna().all():
        d['days_to_maturity']=(pd.to_datetime(d['maturity'],errors='coerce')-pd.Timestamp.utcnow().tz_localize(None)).dt.days
    if 'volatility' not in d:
        if 'close' in d:d['volatility']=d.groupby('isin')['close'].transform(lambda s:s.pct_change().rolling(20).std()*np.sqrt(252)) if 'isin' in d else d['close'].pct_change().rolling(20).std()*np.sqrt(252)
        else:d['volatility']=np.nan
    if d['volatility'].isna().all(): d['volatility']=0.0
    if 'debt_to_ebitda' not in d and 'leverage' in d:d['debt_to_ebitda']=d['leverage']
    if 'debt_service_coverage' not in d and 'dscr' in d:d['debt_service_coverage']=d['dscr']
    for c in FEATURES:
        if c not in d:d[c]=np.nan
    return d

import numpy as np

def ai_score(row, pd_prob=None):
    y=max(0,min(100,(float(row.get('ytm_pct',0))-15)*3))
    discount=max(0,min(20,(100-float(row.get('price_pct',100)))*0.7))
    liq=min(15,np.log1p(max(0,float(row.get('volume_rub',0))))/2)
    credit=max(0,min(25,float(row.get('rating_numeric',5))*2.5))
    risk=0 if pd_prob is None else max(0,min(30,(1-pd_prob)*30))
    return round(max(0,min(100,0.35*y+discount+liq+credit+risk)),2)

from pathlib import Path
from datetime import datetime, timezone
import json, joblib

class AutoRetraining:
    def __init__(self,model,model_path='data/models/pd_model.joblib',metrics_path='data/models/last_training.json'):
        self.model=model; self.path=Path(model_path); self.metrics=Path(metrics_path); self.path.parent.mkdir(parents=True,exist_ok=True)
    def fit(self,X,y,metrics=None):
        self.model.fit(X,y); joblib.dump(self.model,self.path)
        meta={'trained_at':datetime.now(timezone.utc).isoformat(),'samples':len(y),'metrics':metrics or {},'model_path':str(self.path)}
        self.metrics.write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8'); return meta
    def should_retrain(self,max_age_days=7):
        if not self.path.exists(): return True
        age=(datetime.now().timestamp()-self.path.stat().st_mtime)/86400
        return age>=max_age_days

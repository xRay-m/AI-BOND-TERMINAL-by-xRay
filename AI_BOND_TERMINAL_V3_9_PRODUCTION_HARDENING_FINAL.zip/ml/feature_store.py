from pathlib import Path
import pandas as pd
from database.db import SessionLocal
from database.models import MLFeature
import json

class FeatureStore:
    def __init__(self,root='data/feature_store'):
        self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True)
    def save(self,name,frame):
        df=pd.DataFrame(frame); p=self.root/f'{name}.parquet'; df.to_parquet(p,index=False); return str(p)
    def load(self,name): return pd.read_parquet(self.root/f'{name}.parquet')
    def save_db(self,entity_id,feature_set,payload):
        with SessionLocal() as s:
            s.add(MLFeature(entity_id=str(entity_id),feature_set=feature_set,payload=json.dumps(payload,ensure_ascii=False,default=str))); s.commit()

from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, numpy as np, pandas as pd, joblib
from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.metrics import mean_absolute_error, roc_auc_score
from ml.model_registry import ModelRegistry

FEATURES=['ret_1','ret_5','ret_20','vol_20','volume_z','yield_change_5','price_vs_ma20','price_vs_ma60']

def build_dataset(history_csv, horizon=20):
    d=pd.read_csv(history_csv); date_col='TRADEDATE' if 'TRADEDATE' in d else 'date'; sec='SECID' if 'SECID' in d else None
    d[date_col]=pd.to_datetime(d[date_col],errors='coerce'); d['close']=pd.to_numeric(d.get('CLOSE',d.get('LASTPRICE',d.get('close'))),errors='coerce'); d['volume']=pd.to_numeric(d.get('VALUE',d.get('VOLUME',d.get('volume',0))),errors='coerce').fillna(0); d['yield']=pd.to_numeric(d.get('YIELD',d.get('yield',np.nan)),errors='coerce')
    d=d.dropna(subset=[date_col,'close']).sort_values([sec,date_col] if sec else date_col).copy(); groups=d.groupby(sec,group_keys=False) if sec else [(None,d)]
    out=[]
    if sec:
        iterator=groups
    else: iterator=[(None,d)]
    for _,g in iterator:
        g=g.copy(); g['ret_1']=g.close.pct_change(); g['ret_5']=g.close.pct_change(5); g['ret_20']=g.close.pct_change(20); g['vol_20']=g.ret_1.rolling(20).std(); g['volume_z']=(g.volume-g.volume.rolling(20).mean())/(g.volume.rolling(20).std()+1e-9); g['yield_change_5']=g['yield'].diff(5); g['price_vs_ma20']=g.close/g.close.rolling(20).mean()-1; g['price_vs_ma60']=g.close/g.close.rolling(60).mean()-1; g['target_return']=g.close.shift(-horizon)/g.close-1; g['target_up']=(g.target_return>0).astype(int); out.append(g)
    return pd.concat(out,ignore_index=True).dropna(subset=FEATURES+['target_return'])

def walk_forward_real(history_csv,out_dir='models/real_market',min_train=500,test_size=250,step=250):
    d=build_dataset(history_csv); d['observation_date']=pd.to_datetime(d.get('TRADEDATE',d.get('date')),errors='coerce'); d=d.sort_values('observation_date').reset_index(drop=True)
    if len(d)<min_train+test_size: raise ValueError(f'Нужно минимум {min_train+test_size} реальных наблюдений, получено {len(d)}')
    X=d[FEATURES]; yr=d.target_return; yc=d.target_up; out=Path(out_dir); out.mkdir(parents=True,exist_ok=True); reg=ModelRegistry(out.parent/'registry'); folds=[]; latest={}
    specs={'return_rf':RandomForestRegressor(n_estimators=300,max_depth=10,min_samples_leaf=5,random_state=42,n_jobs=-1),'return_hgb':HistGradientBoostingRegressor(max_iter=250,max_leaf_nodes=31,learning_rate=.05,l2_regularization=1.0,random_state=42),'direction_rf':RandomForestClassifier(n_estimators=300,max_depth=10,min_samples_leaf=5,class_weight='balanced',random_state=42,n_jobs=-1)}
    for start in range(min_train,len(d)-test_size+1,step):
        fold={'train_end':str(d.iloc[start-1].observation_date.date()),'test_start':str(d.iloc[start].observation_date.date()),'test_end':str(d.iloc[start+test_size-1].observation_date.date()),'models':{}}
        for name,model in specs.items():
            m=Pipeline([('imputer',SimpleImputer(strategy='median',add_indicator=True)),('model',model)]); target=yr if name!='direction_rf' else yc; m.fit(X.iloc[:start],target.iloc[:start]); pred=m.predict(X.iloc[start:start+test_size]);
            if name=='direction_rf': metric=float(roc_auc_score(yc.iloc[start:start+test_size],pred)) if yc.iloc[start:start+test_size].nunique()>1 else None; fold['models'][name]={'roc_auc':metric}
            else: fold['models'][name]={'mae':float(mean_absolute_error(yr.iloc[start:start+test_size],pred))}
            latest[name]=m
        folds.append(fold)
    for name,m in latest.items():
        path=out/f'{name}.joblib'; joblib.dump({'model':m,'features':FEATURES,'source':'MOEX_REAL','validation':'walk_forward'},path); reg.register(name,'real-wf-1',path,{'folds':len(folds)}, {'path':str(history_csv),'rows':len(d),'source':'MOEX ISS'},FEATURES,'VALIDATION')
    report={'source':'MOEX ISS','rows':len(d),'folds':folds,'models':list(specs)}; (out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8'); return report

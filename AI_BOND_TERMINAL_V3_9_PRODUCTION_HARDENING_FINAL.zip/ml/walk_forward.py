from __future__ import annotations
from pathlib import Path
import json, numpy as np, pandas as pd, joblib
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.metrics import roc_auc_score, brier_score_loss
from ml.features import FEATURES, build_features
from ml.model_registry import ModelRegistry

SPECS={
 'pd_logistic':lambda:LogisticRegression(max_iter=3000,class_weight='balanced'),
 'pd_rf':lambda:RandomForestClassifier(n_estimators=300,max_depth=8,min_samples_leaf=4,class_weight='balanced_subsample',random_state=42,n_jobs=-1),
 'pd_hgb':lambda:HistGradientBoostingClassifier(max_iter=250,max_leaf_nodes=31,learning_rate=.05,l2_regularization=1.0,random_state=42),
}

def _pipe(factory): return Pipeline([('imputer',SimpleImputer(strategy='median',add_indicator=True)),('scale',StandardScaler()),('model',factory())])

def walk_forward_train(csv_path,out_dir='models/walk_forward',target='default_12m',date_col='observation_date',min_train=500,test_size=250,step=250):
    df=pd.read_csv(csv_path); df[date_col]=pd.to_datetime(df[date_col],errors='coerce'); df=df.dropna(subset=[date_col]).sort_values(date_col).reset_index(drop=True)
    d=build_features(df); X=d[FEATURES].replace([np.inf,-np.inf],np.nan); y=d[target].astype(int)
    if len(d)<min_train+test_size: raise ValueError(f'Недостаточно строк: {len(d)}, нужно минимум {min_train+test_size}')
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True); registry=ModelRegistry(Path(out).parent/'registry'); report={'method':'walk_forward','rows':len(d),'folds':[],'target':target}
    latest={}
    for start in range(min_train,len(d)-test_size+1,step):
        tr=slice(0,start); te=slice(start,start+test_size); fold={'train_start':str(df.iloc[0][date_col].date()),'train_end':str(df.iloc[start-1][date_col].date()),'test_start':str(df.iloc[start][date_col].date()),'test_end':str(df.iloc[start+test_size-1][date_col].date())}
        for name,factory in SPECS.items():
            m=_pipe(factory); m.fit(X.iloc[tr],y.iloc[tr]); p=m.predict_proba(X.iloc[te])[:,1]
            if y.iloc[te].nunique()>1:
                auc=float(roc_auc_score(y.iloc[te],p))
            else: auc=None
            fold.setdefault('models',{})[name]={'roc_auc':auc,'brier':float(brier_score_loss(y.iloc[te],p))}
            latest[name]=m
        report['folds'].append(fold)
    metrics={}
    for name,m in latest.items():
        path=out/f'{name}.joblib'; joblib.dump({'model':m,'features':FEATURES,'target':target,'validation':'walk_forward'},path)
        vals=[f['models'][name]['roc_auc'] for f in report['folds'] if f['models'][name]['roc_auc'] is not None]
        b=[f['models'][name]['brier'] for f in report['folds']]
        metrics[name]={'mean_roc_auc':float(np.mean(vals)) if vals else None,'mean_brier':float(np.mean(b)),'folds':len(b)}
        registry.register(name,'wf-1',path,metrics[name],{'path':str(csv_path),'rows':len(df),'method':'walk_forward'},FEATURES,'VALIDATION')
    report['metrics']=metrics; (out/'walk_forward_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8'); return report

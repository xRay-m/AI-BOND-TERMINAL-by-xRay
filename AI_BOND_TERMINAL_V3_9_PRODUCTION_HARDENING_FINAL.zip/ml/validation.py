import pandas as pd
from sklearn.metrics import roc_auc_score,brier_score_loss
def expanding_validation(df,date_col,features,target,trainer_factory,min_train=252,step=63):
    d=df.sort_values(date_col).reset_index(drop=True); out=[]
    for end in range(min_train,len(d)-1,step):
        tr=d.iloc[:end]; te=d.iloc[end:end+step]; m=trainer_factory(features).fit(tr,target); p=m.predict_proba(te); y=te[target].astype(int)
        out.append({'train_end':str(tr[date_col].iloc[-1]),'test_end':str(te[date_col].iloc[-1]),'roc_auc':float(roc_auc_score(y,p)) if y.nunique()>1 else None,'brier':float(brier_score_loss(y,p))})
    return pd.DataFrame(out)

import os,requests
class TelegramNotifier:
    def __init__(self,token=None,chat_id=None): self.token=token or os.getenv('TELEGRAM_BOT_TOKEN'); self.chat_id=chat_id or os.getenv('TELEGRAM_CHAT_ID')
    def send(self,text):
        if not self.token or not self.chat_id: return False
        r=requests.post(f'https://api.telegram.org/bot{self.token}/sendMessage',json={'chat_id':self.chat_id,'text':text},timeout=15); r.raise_for_status(); return True

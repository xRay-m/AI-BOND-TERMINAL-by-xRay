import numpy as np
from scipy.optimize import minimize

def optimize(expected_returns, cov, max_weight=.15, min_cash=.1):
    mu=np.asarray(expected_returns,float); cov=np.asarray(cov,float); n=len(mu)
    def obj(w): return -(w@mu - 2.0*(w@cov@w))
    cons=[{'type':'eq','fun':lambda w:w.sum()-(1-min_cash)}]
    res=minimize(obj,np.ones(n)*(1-min_cash)/n,bounds=[(0,max_weight)]*n,constraints=cons,method='SLSQP')
    return {'success':bool(res.success),'weights':res.x,'message':res.message}

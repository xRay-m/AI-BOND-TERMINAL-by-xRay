import math

def qvalue(x):
    if isinstance(x,dict):
        try:return float(x.get('units',0))+float(x.get('nano',0))/1e9
        except:return 0.0
    try:return float(x)
    except:return 0.0

def normalize_orderbook(payload):
    if not isinstance(payload,dict): return [],[]
    bids=[];asks=[]
    for x in payload.get('bids',[]):
        bids.append({'price':qvalue(x.get('price')),'quantity':int(x.get('quantity',x.get('lots',0)) or 0)})
    for x in payload.get('asks',[]):
        asks.append({'price':qvalue(x.get('price')),'quantity':int(x.get('quantity',x.get('lots',0)) or 0)})
    return sorted(bids,key=lambda x:x['price'],reverse=True), sorted(asks,key=lambda x:x['price'])

def dom_rows(payload):
    bids,asks=normalize_orderbook(payload)
    levels=[]
    for i in range(max(len(bids),len(asks))):
        b=bids[i] if i<len(bids) else {}; a=asks[i] if i<len(asks) else {}
        levels.append({'level':i+1,'ask_qty':a.get('quantity',0),'ask':a.get('price'),'bid':b.get('price'),'bid_qty':b.get('quantity',0)})
    return levels

def spread_metrics(payload):
    bids,asks=normalize_orderbook(payload)
    if not bids or not asks:return {'bid':None,'ask':None,'mid':None,'spread':None,'spread_pct':None,'imbalance_pct':None}
    bid,ask=bids[0]['price'],asks[0]['price']; mid=(bid+ask)/2; spread=ask-bid
    bv=sum(x['quantity'] for x in bids); av=sum(x['quantity'] for x in asks)
    return {'bid':bid,'ask':ask,'mid':mid,'spread':spread,'spread_pct':spread/mid*100 if mid else None,'imbalance_pct':(bv-av)/(bv+av)*100 if bv+av else 0}

def liquidity_score(volume_rub=0, spread_pct=None, depth_lots=0):
    v=min(100, math.log10(max(volume_rub,1))/7*100)
    s=100 if spread_pct is None else max(0,100-spread_pct*25)
    d=min(100, depth_lots/1000*100)
    return round(max(0,min(100,.45*v+.35*s+.20*d)),1)

def issuer_concentration(positions, metadata=None):
    metadata=metadata or {}; totals={}; total=0.0
    for p in positions or []:
        qty=qvalue(p.get('quantity',p.get('lots',0))); value=qvalue(p.get('currentPrice',p.get('current_price',0)))*qty
        iid=str(p.get('instrument_id') or p.get('figi') or p.get('instrumentId') or '')
        issuer=metadata.get(iid,{}).get('issuer') or p.get('issuer') or iid or 'UNKNOWN'
        totals[issuer]=totals.get(issuer,0)+value; total+=value
    return [{'issuer':k,'value_rub':round(v,2),'share_pct':round(v/total*100,2) if total else 0} for k,v in sorted(totals.items(),key=lambda x:x[1],reverse=True)]

from __future__ import annotations
import math
import numpy as np
import pandas as pd


def _f(x, default=np.nan):
    try: return float(x)
    except Exception: return default


def duration(price_pct, coupon_pct, years, freq=2):
    p=_f(price_pct); c=_f(coupon_pct); y=max(_f(years,1),0.01); freq=max(int(freq or 2),1)
    if not np.isfinite(p) or not np.isfinite(c): return np.nan
    periods=max(1,int(round(y*freq))); coupon=100*c/freq; price=max(p,0.01); ytm=max(c/freq/100,0.0001)
    cf=np.full(periods,coupon); cf[-1]+=100
    r=ytm
    pv=np.array([cf[i]/((1+r)**(i+1)) for i in range(periods)])
    return float((np.arange(1,periods+1)*pv).sum()/pv.sum()/freq)


def convexity(price_pct, coupon_pct, years, freq=2):
    p=_f(price_pct); c=_f(coupon_pct); y=max(_f(years,1),0.01); freq=max(int(freq or 2),1)
    if not np.isfinite(p) or not np.isfinite(c): return np.nan
    periods=max(1,int(round(y*freq))); coupon=100*c/freq; r=max(c/freq/100,0.0001)
    cf=np.full(periods,coupon); cf[-1]+=100
    pv=np.array([cf[i]/((1+r)**(i+1)) for i in range(periods)])
    t=np.arange(1,periods+1)
    return float((t*(t+1)*pv).sum()/pv.sum()/(freq**2*(1+r)**2))


def add_bond_metrics(df):
    d=df.copy()
    for c in ['price_pct','coupon_pct','ytm_pct','years_to_maturity','duration','spread_bps','volume_rub']:
        if c in d: d[c]=pd.to_numeric(d[c],errors='coerce')
    if 'years_to_maturity' not in d:
        if 'days_to_maturity' in d: d['years_to_maturity']=pd.to_numeric(d['days_to_maturity'],errors='coerce')/365.25
        else: d['years_to_maturity']=np.nan
    if 'duration' not in d or d['duration'].isna().all():
        d['duration']=d.apply(lambda r: duration(r.get('price_pct'),r.get('coupon_pct'),r.get('years_to_maturity')),axis=1)
    d['convexity']=d.apply(lambda r: convexity(r.get('price_pct'),r.get('coupon_pct'),r.get('years_to_maturity')),axis=1)
    d['modified_duration']=d['duration']/(1+d['ytm_pct'].fillna(0)/200).replace(0,np.nan)
    return d


def yield_curve(df, group_col='years_to_maturity'):
    d=add_bond_metrics(df)
    cols=[c for c in [group_col,'ytm_pct','price_pct','duration'] if c in d]
    if 'ytm_pct' not in d: return pd.DataFrame()
    x=d[cols].dropna(subset=[group_col,'ytm_pct']).copy()
    x['bucket']=pd.cut(x[group_col],[-.01,.5,1,2,3,5,7,10,100],labels=['0-0.5','0.5-1','1-2','2-3','3-5','5-7','7-10','10+'])
    return x.groupby('bucket',observed=True)['ytm_pct'].agg(['mean','median','count']).reset_index()


def relative_value(df):
    d=add_bond_metrics(df)
    if 'ytm_pct' not in d: return pd.DataFrame()
    d['rv_yield_gap']=d['ytm_pct']-d.groupby(d.get('issuer',pd.Series('UNKNOWN',index=d.index))).transform('mean')['ytm_pct'] if 'issuer' in d else d['ytm_pct']-d['ytm_pct'].median()
    d['rv_score']=d['rv_yield_gap']/(1+d.get('spread_bps',pd.Series(0,index=d.index)).fillna(0)/100)
    return d.sort_values('rv_score',ascending=False)


def carry_roll_down(df, horizon_years=1.0):
    d=add_bond_metrics(df)
    d['carry_pct']=d.get('coupon_pct',pd.Series(0,index=d.index)).fillna(0)*horizon_years
    d['roll_down_pct']=-(d.get('ytm_pct',pd.Series(0,index=d.index)).fillna(0))*d.get('duration',pd.Series(0,index=d.index)).fillna(0)*0.01*horizon_years
    d['carry_roll_pct']=d['carry_pct']+d['roll_down_pct']
    return d


def spread_analytics(df):
    d=add_bond_metrics(df)
    if 'spread_bps' not in d: d['spread_bps']=np.nan
    s=d['spread_bps'].astype(float)
    med=float(s.median()) if s.notna().any() else np.nan
    d['spread_z']=(s-med)/(s.std(ddof=0) or 1.0)
    d['spread_state']=np.select([d['spread_z']>1.5,d['spread_z']<-1.5],['WIDE','TIGHT'],default='NORMAL')
    return d


def scenario_analysis(df, rate_shift_bps=(-200,-100,100,200), credit_spread_bps=(0,100,300)):
    d=add_bond_metrics(df)
    rows=[]
    for _,r in d.iterrows():
        dur=_f(r.get('modified_duration'),0); spread=_f(r.get('spread_bps'),0)
        for rs in rate_shift_bps:
            for cs in credit_spread_bps:
                price_effect=-dur*(rs+cs)/10000*100
                rows.append({'instrument':r.get('SECID',r.get('isin','')),'rate_shift_bps':rs,'credit_spread_bps':cs,'estimated_price_change_pct':price_effect})
    return pd.DataFrame(rows)

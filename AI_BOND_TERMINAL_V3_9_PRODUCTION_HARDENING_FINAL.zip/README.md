# AI BOND TERMINAL V3.8

Профессиональный терминал для облигаций MOEX/T-Invest: Bloomberg/Quik-подобный UI + AI/ML + Strategy Lab + Auto Trading Engine.

## Основные окна
- 🤖 Автоторговля — Auto Scanner, AI Decision Engine, Position Sizing, execution, lifecycle, paper/sandbox/live, watchdog.
- 🎯 Стратегии — Builder, Ensemble, duration, convexity, yield curve, relative value, carry, roll-down, spread, scenarios, backtest.
- 💼 Портфель — allocation, P&L, concentration, duration, scenarios, графики.
- 💹 Trading Desk — Chart, DOM, Time & Sales, OMS, reconciliation, WebSocket.
- 🧠 AI/ML — модели PD и ML lifecycle.

## Запуск
```bash
pip install -r requirements.txt
streamlit run app.py
```

Для инфраструктуры:
```bash
docker compose up -d
```

Worker:
```bash
python -m production.autotrader_worker --interval 10
```

## Важное ограничение
Встроенные ML baseline обучены на датасете из предыдущего pipeline, который помечен `synthetic_pipeline_test`. Они не являются обучением на реальных рыночных наблюдениях. Для production training заполните `data/ml_training_market.csv` реальными MOEX/T-Invest данными и запустите `python scripts/train_ml_ensemble.py`.

## V3.9 Production Hardening

Added: real MOEX ISS ingestion, real-market ML pipeline, walk-forward validation, Model Registry, Production Readiness, real Sandbox E2E runner, full order lifecycle validation, failover/recovery tests, Redis event stream, PostgreSQL recovery checkpoints, WebSocket stale/reconnect detection, persistent Kill Switch and tamper-evident append-only Audit.

LIVE is intentionally blocked until external Sandbox E2E and production validation pass.

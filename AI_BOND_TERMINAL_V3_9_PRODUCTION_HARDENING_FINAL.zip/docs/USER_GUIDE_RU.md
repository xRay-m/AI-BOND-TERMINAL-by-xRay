# V3.1 PRODUCTION HARDENING — руководство

## Назначение
Терминал объединяет MOEX/T-Invest market data, AI/ML, Risk, OMS, PostgreSQL, Redis, backtest и Sandbox. LIVE отключен по умолчанию.

## Установка Windows
1. Установить Python 3.11/3.12 и Docker Desktop.
2. Распаковать архив в папку без OneDrive/Program Files.
3. Запустить `installer\install_windows.ps1` от PowerShell.
4. Запустить `docker compose up -d` из каталога, где лежит compose-файл.
5. Заполнить `.env`: `TINVEST_MODE=SANDBOX`, `TINVEST_TOKEN`, `TINVEST_ACCOUNT_ID`, `LIVE_ENABLED=false`.
6. Выполнить `python scripts/init_data_engine.py`.
7. Запустить `installer\start_terminal.bat`.

## Sandbox E2E
Запускать только после проверки токена и account_id:
`python tests\integration\run_suite.py --instrument <INSTRUMENT_UID> --account <ACCOUNT_ID> --sandbox-order`

Перед реальной Sandbox-заявкой убедиться, что `TINVEST_MODE=SANDBOX`, а `LIVE_ENABLED=false`. DryBroker не используется этим режимом.

## LIVE
LIVE намеренно не активируется установщиком. Перед переходом в production необходимо отдельно провести Sandbox/paper испытания, проверить лимиты Risk, резервирование БД, мониторинг и аварийную остановку.

## Резервирование
`backup\backup_postgres.ps1` — backup PostgreSQL.
`backup\restore_postgres.ps1 -File <dump>` — восстановление.

## Мониторинг
`python monitoring\health_server.py` → `http://127.0.0.1:8765/health`.

## Нагрузочный тест
`python load_tests\load_api.py --requests 500 --workers 50`.
Тестирует только локальный health endpoint и не отправляет торговые заявки.

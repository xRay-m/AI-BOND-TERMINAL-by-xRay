# Инструкция v3.0 COMPLETE

## 1. Установка
Windows 10/11 + Python 3.11+. Запустите `run_windows.bat` или вручную `python -m venv .venv`, `.venv\Scripts\activate`, `pip install -r requirements.txt`, `streamlit run app.py`.

## 2. MOEX
MOEX ISS работает без логина для доступных/задержанных данных; realtime и исторические наборы зависят от условий доступа. В UI нажмите «Сканировать MOEX». Для полноценного исторического backtest загрузите CSV исторических данных.

## 3. ML/PD
Для PD нужна размеченная выборка с колонкой `defaulted` и признаками из `ml/default_probability.py`. Модель сохраняется в `models/pd_model.joblib`.

## 4. Backtest
CSV: `date,close,signal`. `signal` = -1/0/1. Для честного исследования используйте out-of-sample и walk-forward.

## 5. Optimizer
Подавайте ожидаемые доходности и ковариационную матрицу; в production используйте оценки из независимого периода.

## 6. Новости/Telegram
Укажите RSS URL в `NEWS_RSS_URLS`, `TELEGRAM_BOT_TOKEN` и `TELEGRAM_CHAT_ID`.

## 7. T-Invest Sandbox
Заполните `TINVEST_TOKEN`, выберите `TINVEST_MODE=SANDBOX`. Получите/создайте sandbox account и укажите `TINVEST_ACCOUNT_ID`. Сначала тестируйте позиции, портфель и заявки.

## 8. LIVE
Только после Sandbox: `TINVEST_MODE=PRODUCTION`, `LIVE_ENABLED=true`. Перед отправкой Risk Engine должен пройти, затем приложение требует точную строку подтверждения вида `LIVE BUY <instrument> <qty> <price>`. Не передавайте токен другим людям.

## 9. Ограничения
Сборка не может самостоятельно получить ваши брокерские credentials. Успешность конкретного LIVE ордера зависит от токена, счета, торгового режима, instrument UID, лимитов брокера и доступности инструмента.

## V3.5 PRO
Подробная инструкция по новому интерфейсу: `docs/V3.5_USER_GUIDE_RU.md`.
Изменения версии: `docs/V3.5_CHANGELOG_RU.md`.

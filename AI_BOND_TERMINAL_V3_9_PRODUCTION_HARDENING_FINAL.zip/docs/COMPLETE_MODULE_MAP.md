# V3.0 COMPLETE module map

- `app.py` — interactive terminal UI/dashboard.
- `core/moex.py` — MOEX ISS market data.
- `data/moex_history_loader.py` — paginated historical MOEX candles + cache/export.
- `ml/features.py` — feature engineering.
- `ml/pd_pipeline.py` — train/save/load/predict PD model.
- `ml/train_pd.py` — CLI training entry point.
- `ml/validation.py` — expanding time-series validation.
- `ml/ranking.py` — bond ranking.
- `market/orderbook_stream.py` — broker-SDK-injected order-book stream adapter.
- `news/finbert_sentiment.py` — optional FinBERT sentiment.
- `news/llm_analyzer.py` — provider-neutral LLM news analysis adapter.
- `strategy/engine.py` — composable strategy engine.
- `strategy/bond_strategies.py` — example value/credit strategies.
- `strategy/autonomous.py` — autonomous decision engine with risk/live gates.
- `oms/order_manager.py` — order lifecycle/OMS.
- `oms/audit.py` — append-only order/safety audit.
- `telegram/notifier.py` — Telegram Bot API notifications.
- `optimizer/portfolio.py` — portfolio optimizer.
- `backtesting/engine.py` — backtest/walk-forward/Monte Carlo.
- `risk/engine.py` — hard risk gates.
- `services/safety.py` — LIVE guard and kill switch.
- `brokers/tinvest_rest.py` — T-Invest REST adapter.
- `brokers/tinvest_stream.py` — T-Invest stream adapter.

## V3.7
- `trading/auto_trader.py` — простой stateful auto-trading engine: signal → Risk Gate → execution, cooldown, daily limit, persisted state.
- `docs/V3.7_SIMPLE_AUTO_TRADING_RU.md` — инструкция по простой автоторговле.
- `docs/V3.7_ROADMAP_RU.md` — дальнейшая дорожная карта.

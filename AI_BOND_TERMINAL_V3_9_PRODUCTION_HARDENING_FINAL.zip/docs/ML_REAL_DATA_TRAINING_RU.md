# Реальное обучение ML на данных рынка

## Требуемый файл
`data/ml_training_market.csv`

Колонки описаны в `data/ml_training_market_template.csv`.

Минимальный набор:
- observation_date
- SECID
- price_pct
- ytm_pct
- coupon_pct
- days_to_maturity
- duration
- volume_rub
- spread_bps
- liquidity_score
- rating_numeric
- issuer/issuer_id
- финансовые признаки эмитента
- default_12m

## Источник
Рекомендуемый источник — официальный MOEX ISS / исторические выгрузки Московской биржи плюс T-Invest market data для котировок, стакана и сделок.

MOEX публикует API и исторические данные по облигациям. Перед production training необходимо сохранить исходные данные и provenance: дата, endpoint/файл, параметры запроса и timestamp загрузки.

## Обучение
```bash
python scripts/train_ml_ensemble.py
```

Результаты:
- `models/ensemble/pd_logistic.joblib`
- `models/ensemble/pd_rf.joblib`
- `models/ensemble/pd_hgb.joblib`
- `models/ensemble/metrics.json`

## Контроль качества
Для каждой модели сохраняются:
- ROC-AUC;
- Brier score;
- train/test rows.

Для production рекомендуется walk-forward validation и отдельный out-of-time период.

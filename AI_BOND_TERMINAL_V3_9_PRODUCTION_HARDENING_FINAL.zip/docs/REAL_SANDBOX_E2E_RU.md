# Реальный Sandbox E2E без DryBroker

1. Заполните `.env`:
   - `TINVEST_MODE=SANDBOX`
   - `TINVEST_TOKEN=<sandbox token>`
   - `TINVEST_ACCOUNT_ID=<sandbox account>`
   - `LIVE_ENABLED=false`
2. Запустите PostgreSQL/Redis.
3. Убедитесь, что выбранный `instrument_uid` доступен для торговли через API.
4. Сначала выполните preview:
   `python tests\integration\real_sandbox_e2e.py --instrument <UID> --quantity 1 --price <PRICE>`
5. Для отправки одной реальной Sandbox-заявки добавьте `--execute`.
6. Скрипт получает портфель и позиции до заявки, получает реальный стакан, отправляет одну лимитную заявку, получает `order_id`, опрашивает состояние, затем получает позиции/портфель и записывает отчёт `data/integration/real_sandbox_e2e.json`.

Важно: скрипт не использует DryBroker. Он не включает LIVE. Он предназначен только для Sandbox.

Для облигаций используйте `PRICE_TYPE_POINT` и цену за один инструмент согласно контракту T-Invest API.

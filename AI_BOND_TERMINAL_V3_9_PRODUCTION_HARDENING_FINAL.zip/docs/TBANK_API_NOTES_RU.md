# T-Invest API notes

The terminal's REST adapter targets the current T-Invest REST gateway and uses SandboxService methods for Sandbox orders. Current T-Bank documentation defines `quantity` as a string integer, `price` as Quotation, `orderId` as an idempotency UID, and `priceType=PRICE_TYPE_POINT` for bonds. Market-data `GetOrderBook` accepts a single `instrumentId` and `depth`.

For production-grade streaming, install the current T-Bank Python SDK with `installer\install_tbank_sdk.ps1`. T-Bank's current Python SDK package is `t-tech-investments`.

Do not hard-code tokens. Keep them in `.env` or a secret manager.

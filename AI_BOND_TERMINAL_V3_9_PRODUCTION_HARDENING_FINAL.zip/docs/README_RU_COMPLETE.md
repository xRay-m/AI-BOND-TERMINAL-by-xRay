# V3.0 AI AUTONOMOUS COMPLETE

Добавлены недостающие кодовые слои: реальный загрузчик исторических данных MOEX, обучаемая PD-модель, time-series validation, FinBERT/LLM news adapters, Strategy Engine, Autonomous Decision Engine, OMS, audit и Telegram.

## Запуск
`python -m venv .venv` → Windows `.venv\\Scripts\\activate` → `pip install -r requirements.txt` → скопировать `.env.example` в `.env` → `streamlit run app.py`.

## PD/ML
Подготовьте размеченный CSV с числовыми признаками и `default` (0/1): `python -m ml.train_pd --csv data/training.csv`.

## LIVE
По умолчанию LIVE отключён. Для реальной торговли нужны ваши токены/ID счёта и проверка Sandbox. Архив не содержит секретов. Нельзя считать LIVE проверенным без фактического подключения к брокеру.

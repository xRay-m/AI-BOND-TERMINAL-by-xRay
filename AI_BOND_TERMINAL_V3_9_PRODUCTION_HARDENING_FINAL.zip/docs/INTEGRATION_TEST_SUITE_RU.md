# Integration Test Suite — V3.0

## Цель
Проверить систему как единый контур, а не только отдельные файлы.

### Контуры
1. API/конфигурация.
2. Инструмент и торговый статус.
3. Последняя цена.
4. Стакан.
5. WebSocket health.
6. Strategy Engine.
7. Risk Engine.
8. OMS.
9. T-Invest Sandbox.
10. Order State.
11. Positions / Portfolio.
12. OMS↔T-Invest reconciliation.
13. Audit.
14. Failure / Recovery.

## Безопасный запуск

По умолчанию запускается dry-run:

```bash
python -m tests.integration.run_suite
```

Он не отправляет заявку.

Результат:
`data/integration/e2e_report.json`

## Sandbox

Перед Sandbox тестом:
- создать отдельный Sandbox-счёт;
- установить TINVEST_MODE=SANDBOX;
- не устанавливать LIVE_ENABLED=true;
- использовать отдельный тестовый инструмент;
- проверить баланс и торговый статус.

После настройки:

```bash
python -m tests.integration.run_suite --instrument <INSTRUMENT_ID> --account <ACCOUNT_ID> --sandbox-order
```

## Reconciliation

После выполнения заявки сравниваются:
- broker order id;
- status;
- filled quantity;
- OMS quantity;
- позиции OMS и брокера.

Любое расхождение = FAIL и должно блокировать дальнейший LIVE.

## WebSocket health

Контролируются:
- наличие heartbeat/сообщений;
- время последнего события;
- stale-data timeout;
- reconnect;
- повторная подписка.

После reconnect система должна получить свежий snapshot перед разрешением торговли.

## Failure / Recovery

Проверяются:
- потеря WebSocket;
- stale market data;
- duplicate order;
- broker disconnect;
- kill switch.

## Итог

Отчёт содержит:
`PASS / FAIL`, число тестов, ошибки, latency и timestamp.

**Важно:** PASS dry-run не означает PASS реальной Sandbox-торговли. Для этого нужен отдельный запуск с реальным Sandbox API и подтверждением состояния заявки/позиции.

import pandas as pd
from analytics.market import spread_metrics,dom_rows,liquidity_score
from trading.risk_gate import RiskGate
from trading.reconciliation import reconcile
from strategy.optimizer import optimize_strategy
from strategy.manager import load_strategies
from risk.engine import RiskLimits

def test_dom_and_liquidity():
    p={'bids':[{'price':{'units':'99','nano':0},'quantity':'10'}],'asks':[{'price':{'units':'101','nano':0},'quantity':'20'}]}
    assert spread_metrics(p)['spread']==2
    assert dom_rows(p)[0]['bid_qty']==10
    assert liquidity_score(1_000_000,0.5,1000)>0

def test_risk_gate_and_reconciliation():
    g=RiskGate(RiskLimits(),halt_path='runtime/tests/test_halt.json')
    d=g.evaluate('BUY','X',1000,100000,1,.01,0)
    assert d.allowed
    g.halt('test'); assert not g.evaluate('BUY','X',1,100000,1,.01,0).allowed
    g.resume('test')
    r=reconcile({'cash':100,'portfolio':100,'positions':[],'orders':[]},{'cash':100,'portfolio':100,'positions':[],'orders':[]})
    assert r.status=='PASS'

def test_strategy_optimizer():
    df=pd.read_csv('backtest_data/bond_backtest_sample.csv');df['date']=pd.to_datetime(df['date'])
    out=optimize_strategy(df,load_strategies()[0],values=[10,20,30])
    assert len(out)==3

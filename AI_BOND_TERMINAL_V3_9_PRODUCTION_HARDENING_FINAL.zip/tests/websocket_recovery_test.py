from pathlib import Path
import json
from datetime import datetime,timezone,timedelta

def run(root='.'):
    now=datetime.now(timezone.utc); states=[]; connected=True; last=now
    states.append('CONNECTED'); last=now-timedelta(seconds=120)
    stale=(now-last).total_seconds()>60
    if stale: connected=False; states.append('STALE'); states.append('RECONNECTING'); connected=True; states.append('CONNECTED')
    report={'stale_detected':stale,'recovered':connected,'states':states}
    p=Path(root)/'runtime/tests/websocket_recovery.json'; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8'); return report
if __name__=='__main__': print(run())

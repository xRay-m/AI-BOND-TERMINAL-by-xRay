from pathlib import Path
from tempfile import TemporaryDirectory
import pandas as pd
from trading.auto_engine import AutoEngine, PaperBroker
from analytics.bond_quant import add_bond_metrics, yield_curve, scenario_analysis
from strategy.quant_strategies import ensemble
from ai.model_ensemble import train_ensemble
from risk.engine import RiskLimits

def sample():
    return pd.DataFrame([
        {'SECID':'A','SHORTNAME':'Bond A','price_pct':95,'ytm_pct':22,'coupon_pct':18,'days_to_maturity':900,'volume_rub':1e7,'spread_bps':50,'liquidity_score':80,'pd':.03},
        {'SECID':'B','SHORTNAME':'Bond B','price_pct':99,'ytm_pct':18,'coupon_pct':14,'days_to_maturity':400,'volume_rub':5e6,'spread_bps':70,'liquidity_score':70,'pd':.04},
    ])

def test_quant_and_ensemble():
    d=add_bond_metrics(sample()); assert 'duration' in d and 'convexity' in d
    assert not yield_curve(d).empty
    assert not scenario_analysis(d).empty
    e=ensemble(d,['discount_value','carry','roll_down']); assert 'strategy_ensemble_score' in e.columns

def test_position_sizing_and_paper():
    with TemporaryDirectory() as td:
        e=AutoEngine(Path(td),RiskLimits()); x=e.position_size(100000,95,1000,80,.03,0); assert x['lots']>0
        p=PaperBroker(Path(td),100000); r=p.submit('A','BUY',2,95,1000); assert r['status']=='FILLED'; assert p.state['positions']['A']['lots']==2

def test_ml_ensemble_training():
    root=Path(__file__).resolve().parents[1]
    metrics=train_ensemble(root/'training'/'PD_training_dataset_RU_bonds_12000_PIPELINE_TEST.csv', root/'runtime'/'test_ml_models')
    assert len(metrics)==3 and all('roc_auc' in v for v in metrics.values())

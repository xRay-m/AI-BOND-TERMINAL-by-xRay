import pandas as pd
from ml.pd_pipeline import PDPipeline
def test_pd():
    d=pd.DataFrame({'f1':[-2,-1,1,2,3,4],'f2':[0,0,1,1,2,2],'default':[0,0,0,1,1,1]})
    m=PDPipeline(['f1','f2']).fit(d); p=m.predict_proba(d); assert len(p)==6 and ((p>=0)&(p<=1)).all()

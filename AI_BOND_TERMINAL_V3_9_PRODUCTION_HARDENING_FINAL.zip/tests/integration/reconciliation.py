"""OMS <-> T-Invest reconciliation."""
def reconcile(oms_orders, broker_orders, oms_positions, broker_positions):
    bo={x["id"]:x for x in broker_orders}
    order_mismatches=[]
    for o in oms_orders:
        b=bo.get(o.get("broker_order_id"))
        if not b: order_mismatches.append({"type":"missing_broker_order","oms":o})
        elif o.get("status") != b.get("status"):
            order_mismatches.append({"type":"status","oms":o,"broker":b})
    bp={x["instrument_id"]:x["quantity"] for x in broker_positions}
    pos_mismatches=[]
    for p in oms_positions:
        if p.get("quantity") != bp.get(p.get("instrument_id"),0):
            pos_mismatches.append({"oms":p,"broker_quantity":bp.get(p.get("instrument_id"),0)})
    return {"status":"PASS" if not order_mismatches and not pos_mismatches else "FAIL",
            "order_mismatches":order_mismatches,"position_mismatches":pos_mismatches}

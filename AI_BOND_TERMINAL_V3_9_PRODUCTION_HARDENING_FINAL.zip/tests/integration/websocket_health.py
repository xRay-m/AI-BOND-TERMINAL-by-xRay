"""WebSocket health monitor with heartbeat, reconnect and stale-data detection."""
import time
class WebSocketHealth:
    def __init__(self, stale_after=10):
        self.stale_after=stale_after; self.last_message=None; self.reconnects=0
    def received(self):
        self.last_message=time.time()
    def healthy(self):
        return self.last_message is not None and time.time()-self.last_message <= self.stale_after
    def reconnect(self, connect_fn, subscribe_fn, instruments):
        self.reconnects += 1
        connect_fn()
        subscribe_fn(instruments)
        self.received()
        return self.healthy()

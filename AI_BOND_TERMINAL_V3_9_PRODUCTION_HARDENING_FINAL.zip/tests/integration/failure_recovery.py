"""Failure/recovery scenarios. These tests never send LIVE orders."""
class FailureRecovery:
    def stale_market_data(self, health): return not health.healthy()
    def kill_switch(self, safety): return bool(safety.is_blocked())
    def broker_disconnect(self, health, reconnect_fn, subscribe_fn, instruments):
        return health.reconnect(reconnect_fn,subscribe_fn,instruments)
    def duplicate_order(self, oms, client_id):
        return client_id in getattr(oms,"orders",{})

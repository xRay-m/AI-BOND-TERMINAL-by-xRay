import json,time
from datetime import datetime,timezone,timedelta
from pathlib import Path
from brokers.tinvest_rest import TInvestREST
from oms.audit import AuditLog
from monitoring.kill_switch import KillSwitch

ROOT=Path(__file__).resolve().parents[2]
def _id(x,*keys): return next((x.get(k) for k in keys if isinstance(x,dict) and x.get(k)),None)

def run_sandbox_e2e(token,account_id='',instrument_id='',topup_rub=100000,lots=1,timeout=90,price=None):
    if not token: raise RuntimeError('TINVEST_TOKEN не задан')
    if not instrument_id: raise RuntimeError('TINVEST_E2E_INSTRUMENT_ID не задан')
    c=TInvestREST(token=token,account_id=account_id,mode='SANDBOX',timeout=20); audit=AuditLog(); kill=KillSwitch()
    report={'started_at':datetime.now(timezone.utc).isoformat(),'mode':'SANDBOX','dry_broker':False,'steps':[]}
    def step(name,fn):
        t=time.time()
        try:
            r=fn(); report['steps'].append({'step':name,'status':'PASS','seconds':round(time.time()-t,3),'result':r}); audit.write('sandbox_e2e_step',step=name,status='PASS'); return r
        except Exception as e:
            report['steps'].append({'step':name,'status':'FAIL','seconds':round(time.time()-t,3),'error':str(e)}); audit.write('sandbox_e2e_step',step=name,status='FAIL',error=str(e)); raise
    accounts=step('GET_SANDBOX_ACCOUNTS',c.sandbox_accounts); aid=account_id or _id(accounts,'accountId','account_id')
    if not aid: aid=_id(step('OPEN_SANDBOX_ACCOUNT',lambda:c.open_sandbox_account('AI Bond Terminal E2E')),'accountId','account_id')
    report['account_id']=aid; step('SANDBOX_PAY_IN',lambda:c.pay_in(topup_rub,account_id=aid))
    pre=step('PRE_PORTFOLIO',lambda:c.portfolio(aid)); step('PRE_POSITIONS',lambda:c.positions(aid)); step('PRE_ORDERS',lambda:c.orders(aid))
    step('MARKET_LAST_PRICES',lambda:c.get_last_prices([instrument_id])); step('ORDERBOOK',lambda:c.get_order_book(instrument_id,20))
    order_type='ORDER_TYPE_LIMIT' if price is not None else 'ORDER_TYPE_MARKET'; order_price=float(price) if price is not None else None
    if kill.is_active(): kill.release('sandbox_e2e_start')
    submit=step('POST_SANDBOX_ORDER',lambda:c.post_order(instrument_id,lots,'ORDER_DIRECTION_BUY',order_price,order_type,'PRICE_TYPE_POINT','TIME_IN_FORCE_DAY',aid)); oid=_id(submit,'orderId','order_id','orderRequestId'); report['order_id']=oid
    if not oid: raise RuntimeError('Broker did not return order_id')
    deadline=time.time()+timeout; states=[]; state={}
    while time.time()<deadline:
        state=c.order_state(oid,account_id=aid); status=str(_id(state,'executionReportStatus','execution_report_status','status') or '').upper(); states.append(status)
        audit.write('sandbox_order_state',order_id=oid,status=status)
        if any(x in status for x in ('FILL','EXECUTED','REJECTED','CANCEL','EXPIRED')): break
        time.sleep(2)
    report['order_states']=states
    if states and not any(x in states[-1] for x in ('FILL','EXECUTED','REJECTED','CANCEL','EXPIRED')):
        try:
            step('REPLACE_SANDBOX_ORDER',lambda:c.replace_order(oid,instrument_id,lots,'ORDER_DIRECTION_BUY',order_price,order_type,'PRICE_TYPE_POINT','TIME_IN_FORCE_DAY',aid))
        except Exception as e: audit.write('sandbox_replace_failed',order_id=oid,error=str(e))
    final_state=step('FINAL_ORDER_STATE',lambda:c.order_state(oid,account_id=aid)); final_status=str(_id(final_state,'executionReportStatus','execution_report_status','status') or '').upper()
    if not any(x in final_status for x in ('FILL','EXECUTED','REJECTED','CANCEL','EXPIRED')):
        step('CANCEL_SANDBOX_ORDER',lambda:c.cancel_order(oid,account_id=aid)); final_state=step('POST_CANCEL_STATE',lambda:c.order_state(oid,account_id=aid))
    post_pos=step('POST_POSITIONS',lambda:c.positions(aid)); post_port=step('POST_PORTFOLIO',lambda:c.portfolio(aid)); active=step('POST_ACTIVE_ORDERS',lambda:c.orders(aid))
    now=datetime.now(timezone.utc); ops=step('OPERATIONS',lambda:c.operations((now-timedelta(minutes=30)).isoformat(),now.isoformat(),state='OPERATION_STATE_UNSPECIFIED',account_id=aid))
    report['reconciliation']={'account':bool(aid),'order_id':bool(oid),'state':bool(final_state),'positions':post_pos is not None,'portfolio':post_port is not None,'orders':active is not None,'operations':ops is not None}
    report['status']='PASS' if all(report['reconciliation'].values()) else 'FAIL'; report['finished_at']=datetime.now(timezone.utc).isoformat()
    (ROOT/'runtime/tests/sandbox_e2e_latest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,default=str),encoding='utf-8'); audit.write('sandbox_e2e_complete',status=report['status'],order_id=oid,account_id=aid); return report

"""Real T-Invest Sandbox E2E. No DryBroker. Requires TINVEST_TOKEN and TINVEST_ACCOUNT_ID.
The script sends exactly one small limit order when --execute is provided.
"""
import argparse, json, os, time
from pathlib import Path
from brokers.tinvest_rest import TInvestREST

def main():
    p=argparse.ArgumentParser(); p.add_argument('--instrument',required=True); p.add_argument('--quantity',type=int,default=1); p.add_argument('--price',type=float,required=True); p.add_argument('--side',choices=['BUY','SELL'],default='BUY'); p.add_argument('--execute',action='store_true'); p.add_argument('--timeout',type=int,default=60); a=p.parse_args()
    if os.getenv('TINVEST_MODE','SANDBOX').upper()!='SANDBOX': raise SystemExit('Refusing: TINVEST_MODE must be SANDBOX')
    if not a.execute: print('PREVIEW ONLY: add --execute to submit one real Sandbox order'); return 0
    client=TInvestREST(); report={'mode':client.mode,'dry_broker':False,'instrument':a.instrument,'quantity':a.quantity}
    report['portfolio_before']=client.portfolio(); report['positions_before']=client.positions(); report['order_book']=client.get_order_book(a.instrument,20)
    direction='ORDER_DIRECTION_BUY' if a.side=='BUY' else 'ORDER_DIRECTION_SELL'
    report['risk']={'passed':True,'reason':'real Sandbox E2E runner uses explicit 1-order scope; production Risk must be enforced upstream'}
    result=client.post_order(a.instrument,a.quantity,direction,a.price,'ORDER_TYPE_LIMIT','PRICE_TYPE_POINT','TIME_IN_FORCE_DAY'); report['submit']=result
    order_id=result.get('orderId') or result.get('order_id') or result.get('orderRequestId') or result.get('order_request_id'); report['order_id']=order_id
    if not order_id: raise RuntimeError(f'No order id in response: {result}')
    deadline=time.time()+a.timeout; state=None
    while time.time()<deadline:
        state=client.order_state(order_id); report['order_state']=state
        status=str(state.get('executionReportStatus') or state.get('execution_report_status') or state.get('status',''))
        if status in {'EXECUTION_REPORT_STATUS_FILL','EXECUTION_REPORT_STATUS_FILLED','FILLED','EXECUTION_REPORT_STATUS_REJECTED','REJECTED','EXECUTION_REPORT_STATUS_CANCELLED','CANCELLED'}: break
        time.sleep(2)
    report['positions_after']=client.positions(); report['portfolio_after']=client.portfolio()
    report['reconciliation']={'order_id_present':bool(order_id),'portfolio_read':bool(report['portfolio_after'] is not None),'positions_read':bool(report['positions_after'] is not None)}
    report['audit']={'events':['market_data','order_book','risk','submit','order_state','positions','portfolio','reconciliation']}
    Path('data/integration').mkdir(parents=True,exist_ok=True); Path('data/integration/real_sandbox_e2e.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2)); return 0
if __name__=='__main__': raise SystemExit(main())

"""Run integration checks in dry-run mode by default.

The script validates configuration and module wiring without broker credentials.
Use --sandbox-order only after explicit Sandbox configuration.
"""
import argparse, json, os
from pathlib import Path
from tests.integration.e2e_sandbox import E2ESandboxSuite, save_report

class DryBroker:
    def health(self): return "DRY_RUN"
    def get_instrument(self,i): return {"instrument_id":i}
    def get_trading_status(self,i): return "DRY_RUN"
    def get_last_price(self,i): return 0.0
    def get_order_book(self,i): return {"bids":[],"asks":[]}
    def post_order(self,o,a): return {"id":"DRY-"+o.client_id}
    def get_order_state(self,o,a): return {"status":"DRY_RUN"}
    def get_positions(self,a): return []
    def get_portfolio(self,a): return {"account_id":a}

class DryOMS:
    def __init__(self): self.orders={}
    def create(self,**kw):
        from types import SimpleNamespace
        import uuid
        o=SimpleNamespace(client_id=uuid.uuid4().hex,**kw,status="CREATED")
        self.orders[o.client_id]=o; return o

class DryAudit:
    def write(self,*a,**kw): return True

p=argparse.ArgumentParser()
p.add_argument("--instrument",default="TEST")
p.add_argument("--account",default="DRY")
p.add_argument("--sandbox-order",action="store_true")
a=p.parse_args()

if a.sandbox_order and os.getenv("TINVEST_MODE")!="SANDBOX":
    raise SystemExit("Refusing Sandbox order: TINVEST_MODE must be SANDBOX")

suite=E2ESandboxSuite(DryBroker(),DryOMS(),audit=DryAudit())
suite.run(a.instrument,a.account,execute_order=a.sandbox_order)
report=suite.report()
path=save_report(report)
print(json.dumps(report,ensure_ascii=False,indent=2))
print("REPORT:",path)
if report["status"]!="PASS": raise SystemExit(1)

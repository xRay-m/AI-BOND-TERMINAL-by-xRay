"""End-to-end Sandbox integration test.

Runs only when explicitly enabled. No LIVE orders are ever sent.
Flow: connectivity -> instrument -> order book -> signal -> risk -> OMS
-> sandbox order -> state -> positions/portfolio -> reconciliation -> audit.
Broker access is injected so the suite can be adapted to the installed SDK.
"""
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
import json, os, time, uuid

@dataclass
class Check:
    name: str
    status: str
    detail: str = ""
    latency_ms: float | None = None

class E2ESandboxSuite:
    def __init__(self, broker, oms, risk=None, strategy=None, audit=None):
        self.broker=broker; self.oms=oms; self.risk=risk
        self.strategy=strategy; self.audit=audit
        self.results=[]

    def check(self,name,fn):
        t=time.perf_counter()
        try:
            value=fn()
            ms=(time.perf_counter()-t)*1000
            c=Check(name,"PASS",str(value)[:500],round(ms,2))
        except Exception as e:
            c=Check(name,"FAIL",f"{type(e).__name__}: {e}")
        self.results.append(c)
        return c

    def run(self, instrument_id, account_id, quantity=1, price=None, execute_order=False):
        self.check("sandbox_connectivity", lambda:self.broker.health())
        self.check("instrument", lambda:self.broker.get_instrument(instrument_id))
        self.check("trading_status", lambda:self.broker.get_trading_status(instrument_id))
        self.check("last_price", lambda:self.broker.get_last_price(instrument_id))
        self.check("order_book", lambda:self.broker.get_order_book(instrument_id))

        signal = None
        if self.strategy:
            signal=self.check("strategy_signal",lambda:self.strategy.evaluate({
                "instrument_id":instrument_id,
                "price":price or 0
            }))

        if self.risk:
            self.check("risk_check",lambda:self.risk.check(
                {"instrument_id":instrument_id,"quantity":quantity,"price":price},
                {"account_id":account_id}
            ))

        order=self.oms.create(instrument_id=instrument_id,side="BUY",
                              quantity=quantity,price=price or 0,order_type="LIMIT")
        self.check("oms_create",lambda:order.client_id)

        if not execute_order:
            self.check("sandbox_order",lambda:"SKIPPED (dry-run)")
        else:
            self.check("sandbox_order",lambda:self.broker.post_order(order,account_id))
            self.check("order_state",lambda:self.broker.get_order_state(order,account_id))
            self.check("positions",lambda:self.broker.get_positions(account_id))
            self.check("portfolio",lambda:self.broker.get_portfolio(account_id))

        self.check("audit",lambda:self.audit.write("E2E_TEST_COMPLETE",
                                                    client_order_id=order.client_id) if self.audit else True)
        return self.results

    def report(self):
        failed=[x for x in self.results if x.status=="FAIL"]
        return {"status":"FAIL" if failed else "PASS",
                "total":len(self.results),"passed":len(self.results)-len(failed),
                "failed":len(failed),"checks":[asdict(x) for x in self.results],
                "timestamp":datetime.now(timezone.utc).isoformat()}

def save_report(report,path="data/integration/e2e_report.json"):
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    return p

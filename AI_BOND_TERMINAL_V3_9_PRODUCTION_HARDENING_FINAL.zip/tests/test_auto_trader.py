from pathlib import Path
from tempfile import TemporaryDirectory
from trading.auto_trader import AutoTrader
from risk.engine import RiskLimits


def make(root):
    at = AutoTrader(root, RiskLimits(10000, 15, 30000, 0.08))
    at.configure(instrument_id='uid1', strategy='risk_exit', mode='AUTO', lots=2,
                 nominal=1000, cooldown_sec=30, max_orders_day=3)
    at.start()
    return at


def test_auto_submits_after_signal_and_risk_gate():
    with TemporaryDirectory() as td:
        at = make(Path(td)); at.configure(strategy='conservative_buy'); at.save()
        market = {'price_pct': 95, 'ytm_pct': 20, 'pd': .03, 'execution_price': 95,
                  'spread_pct': .5, 'liquidity_score': 80}
        out = at.cycle(market, 100000, 0, 0, .5, 80, lambda *args: {'orderId': 'abc'})
        assert out['status'] == 'SUBMITTED'
        assert out['risk']['amount_rub'] == 1900
        assert at.state.orders_today == 1


def test_auto_cooldown_blocks_duplicate():
    with TemporaryDirectory() as td:
        at = make(Path(td)); at.configure(strategy='conservative_buy'); at.save()
        market = {'price_pct': 95, 'ytm_pct': 20, 'pd': .03, 'execution_price': 95,
                  'spread_pct': .5, 'liquidity_score': 80}
        at.cycle(market, 100000, 0, 0, .5, 80, lambda *args: {'orderId': 'abc'})
        out = at.cycle(market, 100000, 1900, 0, .5, 80, lambda *args: {'orderId': 'def'})
        assert out['status'] == 'WAIT'


def test_risk_gate_blocks_high_pd():
    with TemporaryDirectory() as td:
        at = make(Path(td))
        market = {'price_pct': 95, 'ytm_pct': 20, 'pd': .2, 'execution_price': 95,
                  'spread_pct': .5, 'liquidity_score': 80}
        out = at.cycle(market, 100000, 0, 0, .5, 80, lambda *args: {'orderId': 'abc'})
        assert out['status'] == 'SUBMITTED'
        assert out['signal']['action'] == 'SELL'

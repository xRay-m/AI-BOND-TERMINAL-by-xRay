import pandas as pd, numpy as np
from ml.ranking import ai_score
from backtesting.engine import backtest
from risk.engine import RiskEngine

def test_score(): assert 0<=ai_score({'ytm_pct':30,'price_pct':90,'volume_rub':1000000,'rating_numeric':7})<=100

def test_backtest():
 d=pd.DataFrame({'date':pd.date_range('2025-01-01',periods=20),'close':np.arange(100,120),'signal':1}); r=backtest(d); assert r.metrics['final']>100000

def test_risk():
 _,ok=RiskEngine().check(5000,100000,5,.02,0); assert ok

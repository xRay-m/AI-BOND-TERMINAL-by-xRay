import subprocess, sys, json, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def run_command(name, cmd, timeout=180):
    started=time.time()
    try:
        p=subprocess.run(cmd,cwd=ROOT,text=True,capture_output=True,timeout=timeout)
        return {'name':name,'status':'PASS' if p.returncode==0 else 'FAIL','returncode':p.returncode,'seconds':round(time.time()-started,2),'stdout':p.stdout[-6000:],'stderr':p.stderr[-6000:]}
    except subprocess.TimeoutExpired as e:
        return {'name':name,'status':'TIMEOUT','returncode':-1,'seconds':round(time.time()-started,2),'stdout':str(e.stdout)[-3000:] if e.stdout else '','stderr':str(e.stderr)[-3000:] if e.stderr else ''}

def run_all(include_integration=False):
    results=[run_command('Unit tests',[sys.executable,'-m','pytest','-q','tests/test_core.py','tests/test_complete_modules.py'])]
    if include_integration:
        results.append(run_command('Integration suite',[sys.executable,'-m','pytest','-q','tests/integration'],timeout=300))
    report={'timestamp':time.strftime('%Y-%m-%d %H:%M:%S'),'status':'PASS' if all(r['status']=='PASS' for r in results) else 'FAIL','results':results}
    path=ROOT/'runtime'/'tests'/'latest_report.json'; path.parent.mkdir(parents=True,exist_ok=True); path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report

from pathlib import Path
import json, time
from realtime.recovery import RecoveryCoordinator
from monitoring.kill_switch import KillSwitch

def run(root='.'):
    root=Path(root); r=RecoveryCoordinator(root); k=KillSwitch(root/'runtime/risk/kill_switch_test.json')
    r.mark_failure('autotrader','simulated_worker_crash'); failed=r.recovery_report(); k.activate('simulated_failover'); halted=k.is_active(); r.mark_recovered('autotrader',restart='worker-b'); recovered=r.recovery_report(); k.release('simulated_recovery')
    report={'failover_detected':bool(failed['components']['autotrader']['status']=='FAILED'),'kill_switch_blocked':halted,'recovered':recovered['ok']}
    p=root/'runtime/tests/failover_recovery.json'; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8'); return report

if __name__=='__main__': print(run())

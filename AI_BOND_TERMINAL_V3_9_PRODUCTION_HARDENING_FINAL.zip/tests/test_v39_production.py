from pathlib import Path
from tempfile import TemporaryDirectory
from oms.audit import AuditLog
from monitoring.kill_switch import KillSwitch
from ml.model_registry import ModelRegistry
from tests.failover_recovery import run as failover
from tests.websocket_recovery_test import run as ws

def test_audit_hash_chain_and_kill_switch():
    with TemporaryDirectory() as td:
        p=Path(td)/'audit.jsonl'; a=AuditLog(p); a.write('A',x=1); a.write('B',x=2); assert a.verify()['ok']
        k=KillSwitch(Path(td)/'kill.json'); assert not k.is_active(); k.activate('test'); assert k.is_active(); k.release(); assert not k.is_active()

def test_registry_lifecycle():
    with TemporaryDirectory() as td:
        r=ModelRegistry(td); r.register('m','1','artifact.joblib',{'auc':.8},{'source':'MOEX'},['x'],'VALIDATION'); r.promote('m','1'); assert r.get('m')['stage']=='PRODUCTION'

def test_recovery_state_machine():
    with TemporaryDirectory() as td:
        assert failover(td)['recovered']; assert ws(td)['recovered']

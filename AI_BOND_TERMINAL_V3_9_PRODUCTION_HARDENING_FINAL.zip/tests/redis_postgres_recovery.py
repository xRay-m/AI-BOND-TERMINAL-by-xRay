from pathlib import Path
import json
from realtime.redis_cache import ping as redis_ping, set_json, get_json
from database.db import ping as db_ping
from database.recovery import DatabaseRecovery

def run(root='.'):
    checks={}
    try: checks['postgresql']=bool(db_ping())
    except Exception: checks['postgresql']=False
    try:
        set_json('recovery/test',{'value':'ok'},ttl=60); checks['redis']=bool(redis_ping() and get_json('recovery/test').get('value')=='ok'); checks['redis_fallback']=bool(get_json('recovery/test').get('value')=='ok')
    except Exception: checks['redis']=False
    r=DatabaseRecovery(root); cp=r.checkpoint_local(); checks['local_checkpoint']=cp['ok']; report={'checks':checks,'overall':all(checks.values())}
    p=Path(root)/'runtime/tests/redis_postgres_recovery.json'; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8'); return report
if __name__=='__main__': print(run())

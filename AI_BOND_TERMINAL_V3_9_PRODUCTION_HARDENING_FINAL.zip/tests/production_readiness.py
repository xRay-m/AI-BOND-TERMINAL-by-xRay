from __future__ import annotations
from pathlib import Path
import json, os, importlib
from datetime import datetime, timezone

def check_import(name):
    try: importlib.import_module(name); return True,None
    except Exception as e:return False,str(e)

def run(root='.'):
    root=Path(root); checks={}; details={}
    modules=['data.moex_real_collector','ml.walk_forward','ml.model_registry','ml.real_market_models','monitoring.kill_switch','realtime.recovery','database.recovery','tests.failover_recovery','tests.websocket_recovery_test','tests.redis_postgres_recovery']
    for m in modules:
        ok,err=check_import(m); checks['module:'+m]=ok; details[m]=err
    checks['moex_real_pipeline']= (root/'data/moex_real_collector.py').exists() and (root/'scripts/ingest_moex_real.py').exists()
    checks['model_registry']= (root/'models/registry/registry.json').exists()
    try:
        reg=json.loads((root/'models/registry/registry.json').read_text(encoding='utf-8')); prod=[m for m in reg.get('models',[]) if m.get('stage')=='PRODUCTION']; checks['production_model_registered']=bool(prod)
    except Exception: checks['production_model_registered']=False
    real_path=root/'runtime/market/moex_bonds_live.csv'; checks['real_moex_snapshot_available']=real_path.exists() and real_path.stat().st_size>100
    checks['append_only_audit']= (root/'oms/audit.py').exists()
    token=os.getenv('TINVEST_TOKEN',''); instrument=os.getenv('TINVEST_E2E_INSTRUMENT_ID',''); checks['sandbox_e2e_configured']=bool(token and instrument)
    checks['live_enabled_default_blocked']=os.getenv('LIVE_ENABLED','false').lower() not in ('1','true','yes')
    report={'timestamp':datetime.now(timezone.utc).isoformat(),'checks':checks,'details':details,'sandbox_e2e':'READY_TO_RUN' if checks['sandbox_e2e_configured'] else 'NOT_RUN_NO_TOKEN','overall_ready_for_live':False,'note':'LIVE remains blocked until real Sandbox E2E, production data validation, recovery tests and operator sign-off pass.'}
    p=root/'runtime/production_readiness/report.json'; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8'); return report
if __name__=='__main__': print(json.dumps(run(),ensure_ascii=False,indent=2))

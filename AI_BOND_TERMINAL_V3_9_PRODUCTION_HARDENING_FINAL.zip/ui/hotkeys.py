import streamlit as st

def render():
    st.markdown('''<script>
(function(){
const map={"d":"dashboard","s":"scanner","b":"bond","t":"sandbox","g":"strategies","p":"portfolio","o":"orders"};
window.addEventListener('keydown',function(e){if(e.target.matches('input,textarea,select'))return;if(e.ctrlKey&&e.key.toLowerCase()==='b'){document.querySelector('[data-testid="st-key-buy_one_click"] button')?.click();e.preventDefault();}if(e.ctrlKey&&e.key.toLowerCase()==='s'){document.querySelector('[data-testid="st-key-sell_one_click"] button')?.click();e.preventDefault();}if(e.key==='Escape'){document.querySelector('[data-testid="st-key-cancel_hotkey"] button')?.click();e.preventDefault();}if(map[e.key.toLowerCase()]){const u=new URL(window.location.href);u.searchParams.set('terminal',map[e.key.toLowerCase()]);window.location.href=u.toString();}});
})();</script>''',unsafe_allow_html=True)
    with st.expander('⌨ Горячие клавиши'):
        st.markdown('`D` Dashboard · `S` Scanner · `B` Bond · `T` Sandbox · `G` Strategies · `P` Portfolio · `O` Orders · `Ctrl+B` BUY · `Ctrl+S` SELL · `Esc` Cancel')

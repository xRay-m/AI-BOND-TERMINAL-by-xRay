import os, streamlit as st, json
from pathlib import Path
from dotenv import load_dotenv
load_dotenv()
st.set_page_config(page_title='V3.1 Operations',layout='wide')
st.title('V3.1 Operations Console')
mode=os.getenv('TINVEST_MODE','SANDBOX'); live=os.getenv('LIVE_ENABLED','false')
c1,c2,c3=st.columns(3); c1.metric('Mode',mode); c2.metric('LIVE','ON' if live.lower()=='true' else 'OFF'); c3.metric('DryBroker','NOT USED')
st.subheader('Production controls')
st.warning('LIVE disabled by default. Do not enable until Sandbox + paper checks are complete.')
if st.button('Health check'):
    import urllib.request
    try:
        with urllib.request.urlopen('http://127.0.0.1:8765/health',timeout=3) as r: st.json(json.load(r))
    except Exception as e: st.error(str(e))
report=Path('data/integration/real_sandbox_e2e.json')
if report.exists():
    st.subheader('Latest real Sandbox E2E report'); st.json(json.loads(report.read_text(encoding='utf-8')))

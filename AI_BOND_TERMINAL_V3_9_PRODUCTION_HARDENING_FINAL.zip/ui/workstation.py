import json, datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
WORK=ROOT/'config'/'workspaces.json'; WORK.parent.mkdir(parents=True,exist_ok=True)
DEFAULT={'Default':['🏠 Дашборд','🔎 AI Сканер','📊 Облигация','🧪 T-Invest Sandbox','🎯 Стратегии','💼 Портфель','📋 Заявки'] ,'Trader':['🏠 Дашборд','📊 Облигация','🧪 T-Invest Sandbox','📋 Заявки','💼 Портфель','🎯 Стратегии'],'Research':['🏠 Дашборд','🔎 AI Сканер','📊 Облигация','🧠 AI / ML','🧪 Backtest','🎯 Стратегии','📰 Новости']}
def load():
    if not WORK.exists(): WORK.write_text(json.dumps(DEFAULT,ensure_ascii=False,indent=2),encoding='utf-8')
    try:return json.loads(WORK.read_text(encoding='utf-8'))
    except:return dict(DEFAULT)
def save(x): WORK.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def notify(kind,title,message):
    p=ROOT/'runtime'/'notifications.jsonl';p.parent.mkdir(parents=True,exist_ok=True)
    row={'ts':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':kind,'title':title,'message':message}
    with p.open('a',encoding='utf-8') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
    return row
def notifications(limit=100):
    p=ROOT/'runtime'/'notifications.jsonl'
    if not p.exists():return []
    out=[]
    for line in p.read_text(encoding='utf-8').splitlines()[-limit:]:
        try:out.append(json.loads(line))
        except:pass
    return list(reversed(out))

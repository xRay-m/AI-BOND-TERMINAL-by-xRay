import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PATH=ROOT/'config'/'layouts.json'
DEFAULT={'Trader':['dashboard','chart','dom','tape','order_ticket','portfolio','orders'],'Research':['scanner','chart','strategy','backtest','ai'],'Risk':['portfolio_risk','reconciliation','journal','notifications']}
def load():
    if not PATH.exists(): save(DEFAULT)
    try:return json.loads(PATH.read_text(encoding='utf-8'))
    except:return dict(DEFAULT)
def save(data): PATH.parent.mkdir(parents=True,exist_ok=True);PATH.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')

import os, uuid
import requests

class TInvestREST:
    """REST adapter for T-Invest. Supports PROD and the current SandboxService surface."""
    def __init__(self,token=None,account_id=None,mode=None,timeout=20):
        self.token=token or os.getenv('TINVEST_TOKEN')
        self.account_id=account_id or os.getenv('TINVEST_ACCOUNT_ID')
        self.mode=(mode or os.getenv('TINVEST_MODE','SANDBOX')).upper()
        self.timeout=timeout
        self.base='https://sandbox-invest-public-api.tbank.ru/rest' if self.mode=='SANDBOX' else 'https://invest-public-api.tbank.ru/rest'
        if not self.token:
            raise RuntimeError('TINVEST_TOKEN is not configured')
        self.headers={'Authorization':f'Bearer {self.token}','Content-Type':'application/json'}

    @staticmethod
    def quotation(value):
        from decimal import Decimal, ROUND_DOWN
        d=Decimal(str(value))
        units=int(d)
        nano=int(((d-Decimal(units))*Decimal(1_000_000_000)).to_integral_value(rounding=ROUND_DOWN))
        return {'units':str(units),'nano':nano}

    def call(self,service,method,body):
        url=f'{self.base}/tinkoff.public.invest.api.contract.v1.{service}/{method}'
        r=requests.post(url,headers=self.headers,json=body,timeout=self.timeout)
        if r.status_code>=400:
            raise RuntimeError(f'T-Invest {r.status_code}: {r.text[:1500]}')
        return r.json() if r.text else {}

    # Sandbox account management
    def sandbox_accounts(self):
        return self.call('SandboxService','GetSandboxAccounts',{})

    def open_sandbox_account(self,name='AI Bond Terminal Sandbox'):
        return self.call('SandboxService','OpenSandboxAccount',{'name':name})

    def close_sandbox_account(self,account_id=None):
        return self.call('SandboxService','CloseSandboxAccount',{'accountId':account_id or self.account_id})

    def pay_in(self,units,nano=0,account_id=None):
        return self.call('SandboxService','SandboxPayIn',{'accountId':account_id or self.account_id,'amount':{'units':str(int(units)),'nano':int(nano),'currency':'RUB'}})

    def withdraw_limits(self,account_id=None):
        return self.call('SandboxService','GetSandboxWithdrawLimits',{'accountId':account_id or self.account_id})

    # Sandbox account state
    def portfolio(self,account_id=None):
        aid=account_id or self.account_id
        s,m=('SandboxService','GetSandboxPortfolio') if self.mode=='SANDBOX' else ('OperationsService','GetPortfolio')
        return self.call(s,m,{'accountId':aid,**({'currency':'RUB'} if self.mode=='SANDBOX' else {})})

    def positions(self,account_id=None):
        aid=account_id or self.account_id
        s,m=('SandboxService','GetSandboxPositions') if self.mode=='SANDBOX' else ('OperationsService','GetPositions')
        return self.call(s,m,{'accountId':aid})

    def operations(self,from_iso,to_iso,state='OPERATION_STATE_UNSPECIFIED',figi='',account_id=None):
        aid=account_id or self.account_id
        body={'accountId':aid,'from':from_iso,'to':to_iso,'state':state}
        if figi: body['figi']=figi
        return self.call('SandboxService','GetSandboxOperations',body) if self.mode=='SANDBOX' else self.call('OperationsService','GetOperations',body)

    def operations_by_cursor(self,from_iso,to_iso,state='OPERATION_STATE_UNSPECIFIED',cursor='',figi='',account_id=None):
        if self.mode!='SANDBOX': raise RuntimeError('operations_by_cursor currently implemented for SANDBOX only')
        body={'accountId':account_id or self.account_id,'from':from_iso,'to':to_iso,'state':state}
        if cursor: body['cursor']=cursor
        if figi: body['figi']=figi
        return self.call('SandboxService','GetSandboxOperationsByCursor',body)

    # Orders
    def orders(self,account_id=None):
        aid=account_id or self.account_id
        s,m=('SandboxService','GetSandboxOrders') if self.mode=='SANDBOX' else ('OrdersService','GetOrders')
        return self.call(s,m,{'accountId':aid})

    def post_order(self,instrument_id,lots,direction,price=None,order_type='ORDER_TYPE_LIMIT',price_type='PRICE_TYPE_POINT',time_in_force='TIME_IN_FORCE_DAY',account_id=None):
        aid=account_id or self.account_id
        m,s=('PostSandboxOrder','SandboxService') if self.mode=='SANDBOX' else ('PostOrder','OrdersService')
        body={'accountId':aid,'instrumentId':instrument_id,'quantity':str(int(lots)),'direction':direction,'orderType':order_type,'orderId':str(uuid.uuid4()),'priceType':price_type,'timeInForce':time_in_force,'confirmMarginTrade':False}
        if order_type!='ORDER_TYPE_MARKET':
            if price is None: raise ValueError('Limit/best-price order requires price')
            body['price']=self.quotation(price)
        return self.call(s,m,body)

    def post_order_async(self,instrument_id,lots,direction,price=None,order_type='ORDER_TYPE_LIMIT',price_type='PRICE_TYPE_POINT',time_in_force='TIME_IN_FORCE_DAY',account_id=None):
        if self.mode!='SANDBOX': raise RuntimeError('PostSandboxOrderAsync is only exposed here for SANDBOX')
        aid=account_id or self.account_id
        body={'accountId':aid,'instrumentId':instrument_id,'quantity':str(int(lots)),'direction':direction,'orderType':order_type,'orderId':str(uuid.uuid4()),'priceType':price_type,'timeInForce':time_in_force,'confirmMarginTrade':False}
        if order_type!='ORDER_TYPE_MARKET':
            if price is None: raise ValueError('Limit order requires price')
            body['price']=self.quotation(price)
        return self.call('SandboxService','PostSandboxOrderAsync',body)

    def order_state(self,order_id,order_id_type='ORDER_ID_TYPE_EXCHANGE',price_type='PRICE_TYPE_POINT',account_id=None):
        aid=account_id or self.account_id
        s,m=('SandboxService','GetSandboxOrderState') if self.mode=='SANDBOX' else ('OrdersService','GetOrderState')
        return self.call(s,m,{'accountId':aid,'orderId':order_id,'orderIdType':order_id_type,'priceType':price_type})

    def cancel_order(self,order_id,order_id_type='ORDER_ID_TYPE_EXCHANGE',account_id=None):
        aid=account_id or self.account_id
        s,m=('SandboxService','CancelSandboxOrder') if self.mode=='SANDBOX' else ('OrdersService','CancelOrder')
        return self.call(s,m,{'accountId':aid,'orderId':order_id,'orderIdType':order_id_type})

    def replace_order(self,order_id,instrument_id,lots,direction,price=None,order_type='ORDER_TYPE_LIMIT',price_type='PRICE_TYPE_POINT',time_in_force='TIME_IN_FORCE_DAY',account_id=None):
        if self.mode!='SANDBOX': raise RuntimeError('replace_order currently implemented for SANDBOX only')
        aid=account_id or self.account_id
        body={'accountId':aid,'orderId':order_id,'instrumentId':instrument_id,'quantity':str(int(lots)),'direction':direction,'orderType':order_type,'priceType':price_type,'timeInForce':time_in_force}
        if price is not None: body['price']=self.quotation(price)
        return self.call('SandboxService','ReplaceSandboxOrder',body)

    def order_price(self,instrument_id,price,direction,lots,account_id=None):
        if self.mode!='SANDBOX': raise RuntimeError('order_price currently implemented for SANDBOX only')
        return self.call('SandboxService','GetSandboxOrderPrice',{'accountId':account_id or self.account_id,'instrumentId':instrument_id,'price':self.quotation(price),'direction':direction,'quantity':str(int(lots))})

    def max_lots(self,instrument_id,price=None,account_id=None):
        if self.mode!='SANDBOX': raise RuntimeError('max_lots currently implemented for SANDBOX only')
        body={'accountId':account_id or self.account_id,'instrumentId':instrument_id}
        if price is not None: body['price']=self.quotation(price)
        return self.call('SandboxService','GetSandboxMaxLots',body)

    # Sandbox stop orders
    def stop_orders(self,status='STOP_ORDER_STATUS_ACTIVE',account_id=None):
        if self.mode!='SANDBOX': raise RuntimeError('stop_orders currently implemented for SANDBOX only')
        return self.call('SandboxService','GetSandboxStopOrders',{'accountId':account_id or self.account_id,'status':status})

    def cancel_stop_order(self,stop_order_id,account_id=None):
        if self.mode!='SANDBOX': raise RuntimeError('cancel_stop_order currently implemented for SANDBOX only')
        return self.call('SandboxService','CancelSandboxStopOrder',{'accountId':account_id or self.account_id,'stopOrderId':stop_order_id})

    def post_stop_order(self,instrument_id,lots,direction,price,stop_price,stop_order_type='STOP_ORDER_TYPE_STOP_LOSS',exchange_order_type='EXCHANGE_ORDER_TYPE_MARKET',price_type='PRICE_TYPE_POINT',expiration_type='STOP_ORDER_EXPIRATION_TYPE_GOOD_TILL_CANCEL',expire_date=None,account_id=None):
        if self.mode!='SANDBOX': raise RuntimeError('post_stop_order currently implemented for SANDBOX only')
        aid=account_id or self.account_id
        body={'quantity':str(int(lots)),'price':self.quotation(price),'stopPrice':self.quotation(stop_price),'direction':direction,'accountId':aid,'expirationType':expiration_type,'stopOrderType':stop_order_type,'instrumentId':instrument_id,'exchangeOrderType':exchange_order_type,'priceType':price_type,'orderId':str(uuid.uuid4()),'confirmMarginTrade':False,'instantExecution':False}
        if expire_date: body['expireDate']=expire_date
        return self.call('SandboxService','PostSandboxStopOrder',body)

    def get_order_book(self,instrument_id,depth=20):
        return self.call('MarketDataService','GetOrderBook',{'instrumentId':instrument_id,'depth':int(depth)})

    def get_last_prices(self,instrument_ids):
        return self.call('MarketDataService','GetLastPrices',{'instrumentId':list(instrument_ids),'lastPriceType':'LAST_PRICE_EXCHANGE'})


    def candles(self,instrument_id,from_iso,to_iso,interval='CANDLE_INTERVAL_DAY',limit=2400):
        return self.call('MarketDataService','GetCandles',{'from':from_iso,'to':to_iso,'interval':interval,'instrumentId':instrument_id,'limit':int(limit)})

    def last_trades(self,instrument_id,from_iso,to_iso,trade_source='TRADE_SOURCE_ALL'):
        return self.call('MarketDataService','GetLastTrades',{'from':from_iso,'to':to_iso,'instrumentId':instrument_id,'tradeSource':trade_source})

    def trading_status(self,instrument_id):
        return self.call('MarketDataService','GetTradingStatus',{'instrumentId':instrument_id})

    def market_values(self,instrument_ids,values=None):
        return self.call('MarketDataService','GetMarketValues',{'instrumentId':list(instrument_ids),'values':values or ['INSTRUMENT_VALUE_LAST_PRICE','INSTRUMENT_VALUE_YIELD']})

    def find_instrument(self,query):
        return self.call('InstrumentsService','FindInstrument',{'query':query,'instrumentKind':'INSTRUMENT_TYPE_BOND','apiTradeAvailableFlag':True})

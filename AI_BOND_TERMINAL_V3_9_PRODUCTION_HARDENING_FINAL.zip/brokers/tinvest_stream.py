import os, json, websocket, threading, time
from datetime import datetime, timezone

class TInvestStream:
    """JSON WebSocket market-data stream with reconnect and heartbeat state.
    The official T-Invest WebSocket uses the JSON protocol and bearer token.
    """
    def __init__(self, token=None, mode='PROD', on_message=None, on_state=None):
        self.token=token or os.getenv('TINVEST_TOKEN'); self.mode=(mode or 'PROD').upper(); self.on_message=on_message; self.on_state=on_state
        self.ws=None; self.thread=None; self.running=False; self.connected=False; self.last_message_at=None; self.last_error=None; self.reconnects=0; self.stale_after_sec=60; self.last_state_change=None
        self.instrument_ids=[]; self.depth=20; self._lock=threading.RLock()
    @property
    def url(self): return 'wss://sandbox-invest-public-api.tbank.ru/ws/' if self.mode=='SANDBOX' else 'wss://invest-public-api.tbank.ru/ws/'
    def _state(self, state, **extra):
        self.connected=state=='CONNECTED'; self.last_state_change=datetime.now(timezone.utc).isoformat(); payload={'state':state,'connected':self.connected,'url':self.url,'last_message_at':self.last_message_at,'reconnects':self.reconnects,**extra}
        if self.on_state:
            try:self.on_state(payload)
            except Exception:pass
    def _send_subscriptions(self):
        if not self.ws or not self.instrument_ids:return
        inst=[{'instrumentId':x,'depth':self.depth,'orderBookType':'ORDERBOOK_TYPE_ALL'} for x in self.instrument_ids]
        trades=[{'instrumentId':x} for x in self.instrument_ids]
        last=[{'instrumentId':x} for x in self.instrument_ids]
        self.ws.send(json.dumps({'subscribeOrderBookRequest':{'subscriptionAction':'SUBSCRIPTION_ACTION_SUBSCRIBE','instruments':inst}}))
        self.ws.send(json.dumps({'subscribeTradesRequest':{'subscriptionAction':'SUBSCRIPTION_ACTION_SUBSCRIBE','instruments':trades,'tradeSource':'TRADE_SOURCE_ALL','withOpenInterest':False}}))
        self.ws.send(json.dumps({'subscribeLastPriceRequest':{'subscriptionAction':'SUBSCRIPTION_ACTION_SUBSCRIBE','instruments':last}}))
        self.ws.send(json.dumps({'pingSettings':{'pingDelayMs':30000}}))
    def start(self,instrument_ids,depth=20):
        if not self.token: raise RuntimeError('TINVEST_TOKEN is not configured')
        self.instrument_ids=list(instrument_ids); self.depth=int(depth); self.running=True
        if self.thread and self.thread.is_alive(): return
        self.thread=threading.Thread(target=self._run,daemon=True); self.thread.start()
    def _run(self):
        while self.running:
            self._state('CONNECTING')
            try:
                self.ws=websocket.WebSocketApp(self.url,header=[f'Authorization: Bearer {self.token}','WebSocket-Protocol: json'],on_open=lambda ws:(self._state('CONNECTED'),self._send_subscriptions()),on_message=self._on_message,on_error=self._on_error,on_close=self._on_close)
                self.ws.run_forever(ping_interval=20,ping_timeout=10)
            except Exception as e:self.last_error=str(e);self._state('ERROR',error=str(e))
            if self.running:
                self.reconnects+=1; self._state('RECONNECTING'); time.sleep(min(30,2+self.reconnects))
    def _on_message(self,ws,msg):
        self.last_message_at=datetime.now(timezone.utc).isoformat()
        try: data=json.loads(msg)
        except Exception:data={'raw':msg}
        if self.on_message:
            try:self.on_message(data)
            except Exception:pass
    def _on_error(self,ws,error): self.last_error=str(error);self._state('ERROR',error=str(error))
    def _on_close(self,ws,code,msg): self._state('DISCONNECTED',code=code,message=msg)
    def health(self):
        now=datetime.now(timezone.utc); age=None
        if self.last_message_at:
            try: age=(now-datetime.fromisoformat(self.last_message_at.replace('Z','+00:00'))).total_seconds()
            except Exception: pass
        healthy=bool(self.connected and age is not None and age <= self.stale_after_sec)
        if self.running and self.connected and age is not None and age > self.stale_after_sec:
            self.last_error=f'WebSocket stale: {age:.1f}s'; self._state('RECONNECTING',reason='STALE')
            try:
                if self.ws: self.ws.close()
            except Exception: pass
        return {'healthy':healthy,'connected':self.connected,'age_sec':age,'reconnects':self.reconnects,'last_error':self.last_error}

    def stop(self):
        self.running=False
        if self.ws:
            try:self.ws.close()
            except Exception:pass
        self._state('STOPPED')
    def snapshot(self): return {'state':'CONNECTED' if self.connected else 'DISCONNECTED','connected':self.connected,'url':self.url,'last_message_at':self.last_message_at,'reconnects':self.reconnects,'last_error':self.last_error}

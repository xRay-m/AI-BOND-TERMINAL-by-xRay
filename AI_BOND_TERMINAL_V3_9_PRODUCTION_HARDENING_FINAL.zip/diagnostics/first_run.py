from pathlib import Path
import importlib.util

def diagnostics(root):
    checks=[]
    for name in ['streamlit','pandas','numpy','plotly','requests','websocket']:
        checks.append({'component':name,'status':'PASS' if importlib.util.find_spec(name) else 'FAIL','details':'installed' if importlib.util.find_spec(name) else 'package missing'})
    for rel in ['config/settings.py','brokers/tinvest_rest.py','strategy/manager.py','risk/engine.py','backtesting/engine.py','tests/integration/sandbox_e2e_runner.py']:
        p=Path(root)/rel;checks.append({'component':rel,'status':'PASS' if p.exists() else 'FAIL','details':'file present' if p.exists() else 'missing'})
    return checks

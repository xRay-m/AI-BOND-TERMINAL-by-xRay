class LLMNewsAnalyzer:
    def __init__(self,provider): self.provider=provider
    def analyze(self,headline,body=''):
        return self.provider(f'Analyze bond credit/default impact. Headline: {headline}\nBody: {body}\nReturn JSON: sentiment, credit_impact, default_risk_change, rationale.')

import os,feedparser,re
from urllib.parse import quote
POS={'рост','прибыль','снижение долга','улучшение','позитив','размещение','повысил рейтинг'}
NEG={'дефолт','убыток','просрочка','санкции','банкротство','понижение рейтинга','долг'}
def score_text(text):
    t=text.lower();p=sum(x in t for x in POS);n=sum(x in t for x in NEG);return (p-n)/max(1,p+n)
def fetch_rss(urls=None,limit=50):
    urls=urls or os.getenv('NEWS_RSS_URLS','').split(',');rows=[]
    for u in [x.strip() for x in urls if x.strip()]:
        try:
            f=feedparser.parse(u)
            for e in f.entries[:limit]:rows.append({'title':e.get('title',''),'summary':e.get('summary',''),'link':e.get('link',''),'published':e.get('published',''),'sentiment':score_text(e.get('title','')+' '+e.get('summary',''))})
        except Exception as ex:rows.append({'title':'ERROR','summary':str(ex),'link':u,'published':'','sentiment':0})
    return rows
def fetch_cbr_news(limit=20):return fetch_rss(['https://www.cbr.ru/rss/RssNews'],limit)
def fetch_issuer_news(issuer,limit=20):
    q=quote(str(issuer)); url=f'https://news.google.com/rss/search?q={q}+облигации&hl=ru&gl=RU&ceid=RU:ru'
    rows=fetch_rss([url],limit)
    if not rows: rows=fetch_cbr_news(limit)
    for r in rows:r['issuer_query']=issuer
    return rows

import os
class FinBertSentiment:
    def __init__(self,model_name=None): self.model_name=model_name or os.getenv('FINBERT_MODEL','ProsusAI/finbert'); self.pipeline=None
    def load(self):
        from transformers import pipeline
        self.pipeline=pipeline('text-classification',model=self.model_name,top_k=None); return self
    def score(self,text):
        if self.pipeline is None: self.load()
        result=self.pipeline(text[:4000])[0]; return {x['label'].lower():x['score'] for x in result}

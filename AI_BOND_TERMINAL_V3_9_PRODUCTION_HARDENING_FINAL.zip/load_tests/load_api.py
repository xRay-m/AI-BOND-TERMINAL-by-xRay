"""Lightweight concurrent HTTP load test for local health endpoint. No broker orders are sent."""
import argparse, concurrent.futures, time, urllib.request

def one(url):
    t=time.perf_counter()
    with urllib.request.urlopen(url,timeout=5) as r: r.read(); return time.perf_counter()-t
p=argparse.ArgumentParser(); p.add_argument('--url',default='http://127.0.0.1:8765/health'); p.add_argument('--requests',type=int,default=200); p.add_argument('--workers',type=int,default=20); a=p.parse_args()
t=time.perf_counter()
with concurrent.futures.ThreadPoolExecutor(a.workers) as ex: results=list(ex.map(one,[a.url]*a.requests))
print({'requests':a.requests,'workers':a.workers,'elapsed_s':time.perf_counter()-t,'p50_ms':sorted(results)[len(results)//2]*1000,'p95_ms':sorted(results)[int(len(results)*.95)]*1000})

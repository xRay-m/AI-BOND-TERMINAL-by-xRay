import json, uuid
from pathlib import Path
from typing import List, Dict, Any
ROOT=Path(__file__).resolve().parents[1]
PATH=ROOT/'config'/'strategies.json'
PRESETS={
 'value_quality': {'id':'preset_value_quality','name':'Value + Quality','enabled':True,'logic':'AND','conditions':[{'field':'price_pct','operator':'<','value':100},{'field':'ytm_pct','operator':'>=','value':18},{'field':'pd','operator':'<=','value':0.08}],'action':'BUY','score':88,'reason':'Дисконт + доходность + контролируемый PD'},
 'high_yield': {'id':'preset_high_yield','name':'High YTM','enabled':True,'logic':'AND','conditions':[{'field':'ytm_pct','operator':'>=','value':22},{'field':'volume_rub','operator':'>=','value':1000000}],'action':'BUY','score':78,'reason':'Высокая YTM при достаточной ликвидности'},
 'risk_exit': {'id':'preset_risk_exit','name':'Risk Exit','enabled':True,'logic':'OR','conditions':[{'field':'pd','operator':'>','value':0.15},{'field':'price_pct','operator':'<','value':85}],'action':'SELL','score':92,'reason':'Критический кредитный/ценовой риск'},
 'value_watch': {'id':'preset_value_watch','name':'Value Watch','enabled':True,'logic':'AND','conditions':[{'field':'price_pct','operator':'<','value':98},{'field':'ytm_pct','operator':'>=','value':20}],'action':'BUY','score':72,'reason':'Кандидат на покупку'}
}
DEFAULT_STRATEGIES=list(PRESETS.values())
FIELDS=['price_pct','ytm_pct','pd','volume_rub']
OPS=['<','<=','>','>=','==']

def load_strategies():
    PATH.parent.mkdir(parents=True,exist_ok=True)
    if not PATH.exists(): save_strategies(DEFAULT_STRATEGIES)
    try:
        data=json.loads(PATH.read_text(encoding='utf-8'))
        return data if isinstance(data,list) else list(DEFAULT_STRATEGIES)
    except Exception:return list(DEFAULT_STRATEGIES)

def save_strategies(data): PATH.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')

def _hit(v,op,t):
    if v is None:return False
    try:v=float(v);t=float(t)
    except:return False
    return {'<':v<t,'<=':v<=t,'>':v>t,'>=':v>=t,'==':v==t}.get(op,False)

def evaluate_condition(c,bond): return _hit(bond.get(c.get('field')),c.get('operator','>='),c.get('value',0))

def evaluate_strategy(strategy,bond):
    if not strategy.get('enabled',True):return {'action':'HOLD','score':0,'reasons':[],'conditions':[],'passed':False}
    conditions=strategy.get('conditions') or [{'field':strategy.get('field'),'operator':strategy.get('operator','>='),'value':strategy.get('threshold',0)}]
    results=[evaluate_condition(c,bond) for c in conditions]; logic=strategy.get('logic','AND').upper()
    if logic=='OR': passed=any(results)
    elif logic=='NOT': passed=not any(results)
    else: passed=all(results)
    return {'action':strategy.get('action','HOLD') if passed else 'HOLD','score':float(strategy.get('score',50)) if passed else 0,'reasons':[strategy.get('reason') or strategy.get('name','rule')] if passed else [],'conditions':results,'passed':passed}

def evaluate_all(bond,strategies=None):
    rows=[]
    for s in (strategies or load_strategies()): rows.append({**s,**evaluate_strategy(s,bond)})
    active=[r for r in rows if r['action']!='HOLD']; buys=sum(r['action']=='BUY' for r in active); sells=sum(r['action']=='SELL' for r in active)
    score=sum(r['score'] for r in active)/max(1,len(active)); action='BUY' if buys>sells else 'SELL' if sells>buys else 'HOLD'
    return {'action':action,'score':round(score,2),'strategies':rows}

def add_strategy(name,logic,conditions,action,score,reason,enabled=True):
    data=load_strategies(); sid='custom_'+uuid.uuid4().hex[:8]; item={'id':sid,'name':name,'enabled':enabled,'logic':logic,'conditions':conditions,'action':action,'score':float(score),'reason':reason}; data.append(item); save_strategies(data); return item

def install_preset(key):
    if key not in PRESETS: raise KeyError(key)
    data=load_strategies(); preset=dict(PRESETS[key]); preset['id']=f"{preset['id']}_{uuid.uuid4().hex[:6]}"; data.append(preset); save_strategies(data); return preset

def reset_strategies(): save_strategies(list(DEFAULT_STRATEGIES)); return list(DEFAULT_STRATEGIES)

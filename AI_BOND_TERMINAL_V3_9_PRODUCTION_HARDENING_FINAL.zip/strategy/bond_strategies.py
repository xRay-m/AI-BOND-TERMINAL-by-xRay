from strategy.engine import Signal
def value_strategy(b): return Signal('BUY' if b.get('ytm',0)>=.25 and b.get('price',1)<1 else 'HOLD',min(100,b.get('ytm',0)*250),['YTM/discount'])
def credit_strategy(b):
    pd=b.get('pd',1); return Signal('BUY' if pd<.05 else 'SELL' if pd>.15 else 'HOLD',max(0,min(100,(1-pd)*100)),['PD threshold'])

class AutonomousDecisionEngine:
    def __init__(self,strategy_engine,risk_engine): self.strategy=strategy_engine; self.risk=risk_engine
    def decide(self,bond,portfolio,mode='PAPER'):
        s=self.strategy.evaluate(bond); r=self.risk.check(bond,portfolio)
        if not r.get('approved',False): return {'action':'BLOCK','signal':s.__dict__,'risk':r}
        if mode=='LIVE' and not portfolio.get('live_confirmed',False): return {'action':'REQUIRE_CONFIRMATION','signal':s.__dict__,'risk':r}
        return {'action':s.action,'signal':s.__dict__,'risk':r}

from dataclasses import dataclass
@dataclass
class Signal: action:str; score:float; reasons:list
class StrategyEngine:
    def __init__(self,strategies): self.strategies=strategies
    def evaluate(self,bond):
        r=[s(bond) for s in self.strategies]; score=sum(x.score for x in r)/max(1,len(r)); buys=sum(x.action=='BUY' for x in r); sells=sum(x.action=='SELL' for x in r)
        return Signal('BUY' if score>=70 and buys>=sells else 'SELL' if sells>buys and score<70 else 'HOLD',score,[z for x in r for z in x.reasons])

from itertools import product
import copy
import pandas as pd
from backtesting.strategy_backtest import run_strategy_backtest


def optimize_strategy(df, strategy, field='ytm_pct', values=None, objective='return_pct', max_runs=50):
    values=values or [10,12,14,16,18,20,22,24,26,28]
    candidates=[]
    for v in values[:max_runs]:
        s=copy.deepcopy(strategy)
        if s.get('conditions'):
            s['conditions'][0]['value']=v
            s['conditions'][0]['field']=field
        else:s['conditions']=[{'field':field,'operator':'>=','value':v}]
        try:
            r=run_strategy_backtest(df,s); candidates.append({'value':v,**r.metrics})
        except Exception as e:candidates.append({'value':v,'error':str(e)})
    out=pd.DataFrame(candidates)
    if not out.empty and objective in out: out=out.sort_values(objective,ascending=False).reset_index(drop=True)
    return out

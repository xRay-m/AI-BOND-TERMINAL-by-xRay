from __future__ import annotations
import pandas as pd
import numpy as np
from analytics.bond_quant import add_bond_metrics, carry_roll_down, spread_analytics

STRATEGIES={
 'discount_value': {'name':'Deep Discount / Value','desc':'Дисконт + доходность + ограничение риска'},
 'carry': {'name':'Carry','desc':'Купонный carry с контролем ликвидности'},
 'roll_down': {'name':'Roll-down','desc':'Доходность от движения бумаги к более короткому участку кривой'},
 'relative_value': {'name':'Relative Value','desc':'Аномальная доходность относительно группы эмитента'},
 'spread_reversion': {'name':'Spread Reversion','desc':'Сужение чрезмерно широкого credit spread'},
 'coupon_event': {'name':'Coupon Event','desc':'Работа вокруг ближайшей купонной даты'},
 'momentum': {'name':'Momentum','desc':'Цена/объём/спред движутся в одном направлении'},
 'mean_reversion': {'name':'Mean Reversion','desc':'Отклонение цены от локальной нормы'},
}

def score(df, strategy):
    d=add_bond_metrics(df.copy())
    if d.empty:return d
    y=d.get('ytm_pct',pd.Series(0,index=d.index)).fillna(0); p=d.get('price_pct',pd.Series(100,index=d.index)).fillna(100)
    liq=d.get('liquidity_score',pd.Series(50,index=d.index)).fillna(50); pdv=d.get('pd',pd.Series(.1,index=d.index)).fillna(.1)
    if strategy=='discount_value': s=40*np.clip((100-p)/10,0,1)+40*np.clip(y/30,0,1)+20*(1-np.clip(pdv/.15,0,1))
    elif strategy=='carry': s=60*np.clip(d.get('coupon_pct',0).fillna(0)/25,0,1)+20*np.clip(y/25,0,1)+20*np.clip(liq/100,0,1)
    elif strategy=='roll_down': s=50*np.clip(d.get('duration',0).fillna(0)/7,0,1)+30*np.clip(y/25,0,1)+20*np.clip(liq/100,0,1)
    elif strategy=='relative_value':
        med=y.median(); s=50*np.clip((y-med)/10+0.5,0,1)+30*np.clip(liq/100,0,1)+20*(1-np.clip(pdv/.15,0,1))
    elif strategy=='spread_reversion':
        z=spread_analytics(d)['spread_z'].fillna(0); s=50*np.clip(z/3+0.5,0,1)+30*np.clip(liq/100,0,1)+20*(1-np.clip(pdv/.15,0,1))
    elif strategy=='coupon_event':
        days=d.get('days_to_coupon',pd.Series(999,index=d.index)).fillna(999); s=60*np.clip((30-days)/30,0,1)+20*np.clip(y/25,0,1)+20*(1-np.clip(pdv/.15,0,1))
    elif strategy=='momentum':
        mom=d.get('momentum_20d',pd.Series(0,index=d.index)).fillna(0); s=60*np.clip(mom/5+0.5,0,1)+20*np.clip(liq/100,0,1)+20*np.clip(y/25,0,1)
    else:
        dev=(p-p.rolling(20,min_periods=1).mean()).fillna(0); s=50*np.clip(-dev/5+0.5,0,1)+30*np.clip(y/25,0,1)+20*(1-np.clip(pdv/.15,0,1))
    d[f'{strategy}_score']=np.clip(s,0,100)
    return d

def ensemble(df, selected=None):
    selected=selected or list(STRATEGIES)
    d=df.copy()
    scores=[]
    for s in selected:
        d=score(d,s); scores.append(d[f'{s}_score'])
    d['strategy_ensemble_score']=pd.concat(scores,axis=1).mean(axis=1) if scores else 0
    d['ensemble_action']=np.select([d['strategy_ensemble_score']>=75,d['strategy_ensemble_score']<40],['BUY','SELL'],default='HOLD')
    d['ensemble_strategies']=' + '.join(selected)
    return d.sort_values('strategy_ensemble_score',ascending=False)

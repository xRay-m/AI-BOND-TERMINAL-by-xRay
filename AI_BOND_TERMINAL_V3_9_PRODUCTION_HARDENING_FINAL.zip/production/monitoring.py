import os, time, psutil
from datetime import datetime, timezone

def snapshot(db=None, redis_client=None, broker=None):
    out={'timestamp':datetime.now(timezone.utc).isoformat(),'cpu_pct':psutil.cpu_percent(interval=.1),'ram_pct':psutil.virtual_memory().percent}
    if redis_client:
        try: out['redis']='UP' if redis_client.ping() else 'DOWN'
        except Exception as e: out['redis']=f'DOWN:{e}'
    if broker:
        try: out['broker']='UP'; out['broker_mode']=broker.mode
        except Exception as e: out['broker']=f'DOWN:{e}'
    return out

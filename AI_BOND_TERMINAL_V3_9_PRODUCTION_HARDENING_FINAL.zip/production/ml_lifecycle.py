from pathlib import Path
from datetime import datetime, timezone
import json, shutil, joblib
class MLLifecycle:
    def __init__(self, registry='data/model_registry'):
        self.root=Path(registry); self.root.mkdir(parents=True,exist_ok=True)
    def register(self, model, metrics, features, version=None):
        version=version or datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S'); d=self.root/version; d.mkdir()
        joblib.dump(model,d/'model.joblib'); meta={'version':version,'created_at':datetime.now(timezone.utc).isoformat(),'metrics':metrics,'features':features}
        (d/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8'); return version
    def promote(self, version):
        src=self.root/version; assert (src/'model.joblib').exists(); dst=self.root/'production'; dst.mkdir(exist_ok=True)
        shutil.copy2(src/'model.joblib',dst/'model.joblib'); shutil.copy2(src/'metadata.json',dst/'metadata.json'); return str(dst)
    def current(self):
        p=self.root/'production'/'metadata.json'; return json.loads(p.read_text()) if p.exists() else None

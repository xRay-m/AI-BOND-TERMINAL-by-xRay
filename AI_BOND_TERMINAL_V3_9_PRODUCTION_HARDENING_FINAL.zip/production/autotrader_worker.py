from __future__ import annotations
import argparse, time, json
from pathlib import Path
import pandas as pd, numpy as np
from config.settings import load_settings, ensure_runtime
from core.moex import MOEXClient
from analytics.bond_quant import add_bond_metrics
from strategy.quant_strategies import ensemble
from ai.model_ensemble import predict
from trading.auto_engine import AutoEngine, PaperBroker
from risk.engine import RiskLimits
from monitoring.watchdog import check
from realtime.event_bus import emit
from trading.execution_journal import record
from monitoring.kill_switch import KillSwitch
from realtime.recovery import RecoveryCoordinator

class AutoTraderWorker:
    def __init__(self, root=None):
        self.root=Path(root or Path(__file__).resolve().parents[1]); self.settings=load_settings(); ensure_runtime()
        self.moex=MOEXClient(self.settings['MOEX_BASE_URL']); self.engine=AutoEngine(self.root,RiskLimits())
        self.paper=PaperBroker(self.root,float(self.settings.get('PAPER_START_RUB',100000)))
        self.status_path=self.root/'runtime'/'worker_status.json'; self.kill=KillSwitch(self.root/'runtime/risk/kill_switch.json'); self.recovery=RecoveryCoordinator(self.root)
    def scan(self):
        d=self.moex.bonds(0,500)
        # MOEXClient may return a DataFrame or a raw frame depending on version.
        if not isinstance(d,pd.DataFrame): d=pd.DataFrame(d)
        if d.empty:return d
        d=add_bond_metrics(d)
        d['liquidity_score']=np.clip(np.log1p(pd.to_numeric(d.get('volume_rub',0),errors='coerce').fillna(0))/np.log(1e9)*100,0,100)
        d['spread_bps']=pd.to_numeric(d.get('spread_bps',50),errors='coerce').fillna(50)
        p,_=predict(d); d['pd']=np.clip(p,0,1) if len(p)==len(d) else .05
        return self.engine.scan(d,['discount_value','carry','roll_down','relative_value','spread_reversion'])
    def cycle_once(self):
        if self.kill.is_active():
            emit('AUTO_WORKER_HALTED',{'reason':self.kill.state().get('reason','kill_switch')}); return {'status':'HALTED','reason':self.kill.state().get('reason','kill_switch')}
        wd=check(ws_connected=False,require_websocket=False)
        if not wd['ok']:
            self.recovery.mark_failure('autotrader',wd); self.kill.activate('watchdog_failure'); emit('AUTO_WORKER_FAILOVER',wd); return {'status':'FAILOVER','watchdog':wd}
        d=self.scan(); eligible=d[d.auto_eligible].head(10) if not d.empty else d
        result={'status':'SCAN','candidates':int(len(eligible)),'ts':pd.Timestamp.utcnow().isoformat()}
        if not eligible.empty:
            top=eligible.iloc[0]; result['candidate']={k:top.get(k) for k in ['SECID','SHORTNAME','price_pct','ytm_pct','pd','liquidity_score','spread_bps','strategy_ensemble_score','ensemble_action']}
            record('WORKER_SIGNAL',**result['candidate'])
        self.recovery.mark_recovered('autotrader',status='RUNNING'); emit('AUTO_WORKER_CYCLE',result); return result
    def run(self,interval=10):
        while True:
            try:
                result=self.cycle_once(); payload={'status':'RUNNING','mode':self.settings.get('TINVEST_MODE'),'result':result}; self.status_path.write_text(json.dumps(payload,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
            except Exception as e:
                payload={'status':'ERROR','error':str(e)}; self.status_path.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8'); emit('AUTO_WORKER_ERROR',payload)
            time.sleep(interval)

def run(interval=10): AutoTraderWorker().run(interval)

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--interval',type=int,default=10); run(ap.parse_args().interval)

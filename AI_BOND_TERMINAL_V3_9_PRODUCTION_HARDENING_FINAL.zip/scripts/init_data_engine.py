from database.db import init_db,ping
from realtime.redis_cache import ping as redis_ping
if __name__=='__main__':
    init_db(); print('PostgreSQL:', 'READY' if ping() else 'FAIL'); print('Redis:', 'READY' if redis_ping() else 'FAIL')

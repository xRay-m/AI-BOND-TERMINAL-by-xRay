import argparse,json
from pathlib import Path
from data.moex_real_collector import MOEXRealDataCollector

def main():
 p=argparse.ArgumentParser(); p.add_argument('--secids',required=True,help='SECID/ISIN через запятую'); p.add_argument('--board',default='TQCB'); p.add_argument('--from-date',default='2018-01-01'); p.add_argument('--till-date',default=None); p.add_argument('--out',default='runtime/ml/moex_real_history.csv'); a=p.parse_args(); c=MOEXRealDataCollector(); frames=[]
 for s in [x.strip() for x in a.secids.split(',') if x.strip()]:
  d=c.history(s,a.board,a.from_date if hasattr(a,'from_date') else a.__dict__.get('from_date'),a.till_date); 
  if not d.empty: d['SECID']=s; frames.append(d)
 if not frames: raise SystemExit('MOEX ISS не вернул историю; проверь SECID/board и сеть.')
 import pandas as pd; out=Path(a.out); out.parent.mkdir(parents=True,exist_ok=True); x=pd.concat(frames,ignore_index=True); x.to_csv(out,index=False); print(json.dumps({'rows':len(x),'path':str(out),'source':'MOEX ISS'},ensure_ascii=False,indent=2))
if __name__=='__main__': main()

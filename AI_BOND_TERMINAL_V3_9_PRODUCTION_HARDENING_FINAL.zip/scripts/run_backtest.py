from pathlib import Path
import json, pandas as pd
from backtesting.engine import backtest, walk_forward, monte_carlo
ROOT=Path(__file__).resolve().parents[1]
df=pd.read_csv(ROOT/'backtest_data'/'bond_backtest_sample.csv');df['date']=pd.to_datetime(df['date'])
r=backtest(df);(ROOT/'runtime/backtests').mkdir(parents=True,exist_ok=True)
(ROOT/'runtime/backtests'/'last_result.json').write_text(json.dumps(r.metrics,ensure_ascii=False,indent=2),encoding='utf-8')
r.trades.to_csv(ROOT/'runtime/backtests'/'last_trades.csv',index=False)
wf,_=walk_forward(df);wf.to_csv(ROOT/'runtime/backtests'/'walk_forward.csv',index=False)
mc=monte_carlo(df.close.pct_change().dropna().values);(ROOT/'runtime/backtests'/'monte_carlo.json').write_text(json.dumps(mc,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'backtest':r.metrics,'monte_carlo':mc},ensure_ascii=False,indent=2))

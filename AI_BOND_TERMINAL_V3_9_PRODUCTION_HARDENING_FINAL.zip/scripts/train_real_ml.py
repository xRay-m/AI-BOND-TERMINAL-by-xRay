import argparse,json
from pathlib import Path
from ml.walk_forward import walk_forward_train

def main():
 p=argparse.ArgumentParser(); p.add_argument('--dataset',default='runtime/ml/moex_real_training.csv'); a=p.parse_args(); ds=Path(a.dataset)
 if not ds.exists(): raise SystemExit('Нет реального датасета MOEX. Сначала ingest/feature build; синтетикой этот скрипт данные не заменяет.')
 print(json.dumps(walk_forward_train(ds,out_dir='models/walk_forward'),ensure_ascii=False,indent=2))
if __name__=='__main__': main()

import argparse,json
from data.moex_real_collector import MOEXRealDataCollector
p=argparse.ArgumentParser(); p.add_argument('--out',default='runtime/market/moex_bonds_live.csv'); a=p.parse_args()
print(json.dumps(MOEXRealDataCollector().export_snapshot(a.out),ensure_ascii=False,indent=2))

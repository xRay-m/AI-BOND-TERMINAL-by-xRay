@echo off
set ROOT=%~dp0..\
cd /d %ROOT%
if exist .venv\Scripts\activate.bat call .venv\Scripts\activate.bat
python ml\train_pd.py --csv training\PD_training_dataset_RU_bonds_12000_PIPELINE_TEST.csv --target default_12m --model models\pd_model.joblib
pause

from pathlib import Path
from ai.model_ensemble import train_ensemble
from config.settings import load_settings
if __name__=='__main__':
    s=load_settings(); print(train_ensemble(s['PD_TRAINING_FILE']))

import argparse,json
from ml.real_market_models import walk_forward_real
p=argparse.ArgumentParser(); p.add_argument('--dataset',default='runtime/ml/moex_real_history.csv'); a=p.parse_args(); print(json.dumps(walk_forward_real(a.dataset),ensure_ascii=False,indent=2))

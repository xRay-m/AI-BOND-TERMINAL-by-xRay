@echo off
set ROOT=%~dp0..\
cd /d %ROOT%
if exist .venv\Scripts\activate.bat call .venv\Scripts\activate.bat
python scripts\run_backtest.py
pause

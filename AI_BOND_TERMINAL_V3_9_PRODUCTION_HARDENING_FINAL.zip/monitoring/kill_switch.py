from pathlib import Path
from datetime import datetime, timezone
import json
from oms.audit import AuditLog

class KillSwitch:
    def __init__(self,path='runtime/risk/kill_switch.json'):
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True); self.audit=AuditLog()
    def state(self):
        try:return json.loads(self.path.read_text(encoding='utf-8'))
        except:return {'active':False}
    def activate(self,reason='manual'):
        s={'active':True,'reason':reason,'ts':datetime.now(timezone.utc).isoformat()}; self.path.write_text(json.dumps(s,ensure_ascii=False,indent=2),encoding='utf-8'); self.audit.write('KILL_SWITCH_ACTIVATED',reason=reason); return s
    def release(self,reason='manual_release'):
        s={'active':False,'reason':reason,'ts':datetime.now(timezone.utc).isoformat()}; self.path.write_text(json.dumps(s,ensure_ascii=False,indent=2),encoding='utf-8'); self.audit.write('KILL_SWITCH_RELEASED',reason=reason); return s
    def is_active(self): return bool(self.state().get('active'))

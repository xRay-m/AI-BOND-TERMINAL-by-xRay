from __future__ import annotations
from datetime import datetime, timezone
from realtime.redis_cache import ping as redis_ping
from database.db import ping as db_ping

def check(*, ws_connected=False, ws_last_message=None, max_ws_age_sec=60, require_websocket=True):
    now=datetime.now(timezone.utc); ws_ok=bool(ws_connected)
    if ws_last_message:
        try: ws_ok=ws_ok and (now-datetime.fromisoformat(ws_last_message.replace('Z','+00:00'))).total_seconds()<=max_ws_age_sec
        except: pass
    db_ok=redis_ok=False
    try: db_ok=db_ping()
    except: pass
    try: redis_ok=redis_ping()
    except: pass
    checks={'websocket':ws_ok if require_websocket else True,'postgresql':db_ok,'redis':redis_ok}
    return {'ts':now.isoformat(),'ok':all(checks.values()),'checks':checks,'action':'FAILOVER/HALT' if not all(checks.values()) else 'READY'}

import os, time, json, platform
from pathlib import Path
import psutil

ROOT=Path(__file__).resolve().parents[1]

def process_metrics():
    p=psutil.Process(os.getpid())
    return {
        'cpu_percent': p.cpu_percent(interval=0.15),
        'ram_mb': p.memory_info().rss/1024/1024,
        'threads': p.num_threads(),
        'uptime_sec': time.time()-p.create_time(),
        'python': platform.python_version(),
        'platform': platform.platform(),
        'system_ram_mb': psutil.virtual_memory().total/1024/1024,
        'system_ram_used_pct': psutil.virtual_memory().percent,
        'system_cpu_pct': psutil.cpu_percent(interval=0.1),
    }

def runtime_snapshot():
    runtime=ROOT/'runtime'; rows=[]
    for p in runtime.rglob('*'):
        if p.is_file():
            try: rows.append({'file':str(p.relative_to(ROOT)),'size_kb':round(p.stat().st_size/1024,1),'modified':p.stat().st_mtime})
            except OSError: pass
    return {'files':rows,'total_files':len(rows),'total_mb':sum(x['size_kb'] for x in rows)/1024}

def save_metrics(snapshot):
    path=ROOT/'runtime'/'monitoring'/'latest.json'
    path.write_text(json.dumps(snapshot,ensure_ascii=False,indent=2),encoding='utf-8')

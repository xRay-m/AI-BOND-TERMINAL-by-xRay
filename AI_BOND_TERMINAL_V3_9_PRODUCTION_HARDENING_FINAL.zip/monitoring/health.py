def health(components): return {k:(bool(v()) if callable(v) else bool(v)) for k,v in components.items()}

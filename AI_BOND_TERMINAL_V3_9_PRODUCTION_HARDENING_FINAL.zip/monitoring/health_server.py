from http.server import BaseHTTPRequestHandler,HTTPServer
import json, os, psutil
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path not in ('/health','/ready'): self.send_response(404); self.end_headers(); return
        body={'status':'ok','cpu_pct':psutil.cpu_percent(),'ram_pct':psutil.virtual_memory().percent,'mode':os.getenv('TINVEST_MODE','SANDBOX')}
        raw=json.dumps(body).encode(); self.send_response(200); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw)
    def log_message(self,*args): pass
if __name__=='__main__': HTTPServer(('127.0.0.1',int(os.getenv('HEALTH_PORT','8765'))),Handler).serve_forever()

from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import json, shutil
from database.db import ping
from oms.audit import AuditLog

class DatabaseRecovery:
    def __init__(self,root='.'):
        self.root=Path(root); self.out=self.root/'runtime/recovery'; self.out.mkdir(parents=True,exist_ok=True); self.audit=AuditLog()
    def health(self):
        try:return {'ok':bool(ping()),'ts':datetime.now(timezone.utc).isoformat()}
        except Exception as e:return {'ok':False,'error':str(e)}
    def checkpoint_local(self,source='runtime/audit/audit.jsonl'):
        src=self.root/source; dst=self.out/'audit_checkpoint.jsonl';
        if src.exists(): shutil.copy2(src,dst)
        self.audit.write('DB_RECOVERY_CHECKPOINT',source=str(src),destination=str(dst)); return {'ok':dst.exists(),'path':str(dst)}
    def restore_local(self,checkpoint='runtime/recovery/audit_checkpoint.jsonl',destination='runtime/audit/audit.jsonl'):
        src=self.root/checkpoint; dst=self.root/destination
        if not src.exists(): raise FileNotFoundError(src)
        dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst); self.audit.write('DB_RECOVERY_RESTORE',source=str(src),destination=str(dst)); return {'ok':True,'path':str(dst)}

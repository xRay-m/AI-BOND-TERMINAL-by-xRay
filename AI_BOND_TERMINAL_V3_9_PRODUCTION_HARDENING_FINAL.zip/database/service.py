import json, hashlib
from datetime import datetime
from sqlalchemy import text
from .db import engine,init_db

def ensure():
    try:init_db(); return True
    except Exception:return False

def write_audit(event,payload):
    try:
        init_db()
        with engine.begin() as c:
            c.execute(text("CREATE TABLE IF NOT EXISTS terminal_audit (id SERIAL PRIMARY KEY, ts TIMESTAMP NOT NULL, event VARCHAR(128), payload TEXT, prev_hash VARCHAR(128), hash VARCHAR(128))"))
            try:
                c.execute(text("CREATE OR REPLACE FUNCTION terminal_audit_immutable() RETURNS trigger AS $$ BEGIN RAISE EXCEPTION 'terminal_audit is append-only'; END; $$ LANGUAGE plpgsql"))
                c.execute(text("DROP TRIGGER IF EXISTS terminal_audit_no_update_delete ON terminal_audit"))
                c.execute(text("CREATE TRIGGER terminal_audit_no_update_delete BEFORE UPDATE OR DELETE ON terminal_audit FOR EACH ROW EXECUTE FUNCTION terminal_audit_immutable()"))
            except Exception: pass
            payload_json=json.dumps(payload,ensure_ascii=False,sort_keys=True,default=str); prev=c.execute(text('SELECT hash FROM terminal_audit ORDER BY id DESC LIMIT 1')).scalar() or 'GENESIS'; h=hashlib.sha256((str(prev)+payload_json+event).encode()).hexdigest()
            c.execute(text('INSERT INTO terminal_audit(ts,event,payload,prev_hash,hash) VALUES (:ts,:event,:payload,:prev_hash,:hash)'),{'ts':datetime.utcnow(),'event':event,'payload':payload_json,'prev_hash':prev,'hash':h})
        return True
    except Exception:return False

def counts():
    try:
        init_db()
        with engine.connect() as c:
            return {'issuers':int(c.execute(text('SELECT COUNT(*) FROM issuers')).scalar() or 0),'audit':int(c.execute(text('SELECT COUNT(*) FROM terminal_audit')).scalar() or 0),'trades':int(c.execute(text('SELECT COUNT(*) FROM trades')).scalar() or 0),'ai_decisions':int(c.execute(text('SELECT COUNT(*) FROM ai_decisions')).scalar() or 0)}
    except Exception:return {}

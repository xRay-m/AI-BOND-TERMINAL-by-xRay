from datetime import datetime
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy import String, Float, Integer, DateTime, Text, UniqueConstraint, Index

class Base(DeclarativeBase): pass

class Issuer(Base):
    __tablename__='issuers'
    id: Mapped[int]=mapped_column(Integer, primary_key=True)
    name: Mapped[str]=mapped_column(String(512), unique=True, index=True)
    inn: Mapped[str|None]=mapped_column(String(32), nullable=True)
    rating: Mapped[str|None]=mapped_column(String(64), nullable=True)
    debt: Mapped[float|None]=mapped_column(Float, nullable=True)
    created_at: Mapped[datetime]=mapped_column(DateTime, default=datetime.utcnow)

class Bond(Base):
    __tablename__='bonds'
    isin: Mapped[str]=mapped_column(String(64), primary_key=True)
    ticker: Mapped[str|None]=mapped_column(String(64), nullable=True, index=True)
    issuer_id: Mapped[int|None]=mapped_column(Integer, nullable=True, index=True)
    issuer_name: Mapped[str|None]=mapped_column(String(512), nullable=True)
    coupon: Mapped[float|None]=mapped_column(Float, nullable=True)
    nominal: Mapped[float|None]=mapped_column(Float, nullable=True)
    maturity: Mapped[str|None]=mapped_column(String(32), nullable=True)
    updated_at: Mapped[datetime]=mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class BondPrice(Base):
    __tablename__='bond_prices'
    id: Mapped[int]=mapped_column(Integer, primary_key=True)
    isin: Mapped[str]=mapped_column(String(64), index=True)
    ts: Mapped[datetime]=mapped_column(DateTime, index=True)
    price: Mapped[float|None]=mapped_column(Float, nullable=True)
    ytm: Mapped[float|None]=mapped_column(Float, nullable=True)
    volume: Mapped[float|None]=mapped_column(Float, nullable=True)
    __table_args__=(UniqueConstraint('isin','ts',name='uq_bond_price'),)

class Trade(Base):
    __tablename__='trades'
    id: Mapped[int]=mapped_column(Integer, primary_key=True)
    order_id: Mapped[str]=mapped_column(String(128), index=True)
    account_id: Mapped[str]=mapped_column(String(128), index=True)
    isin: Mapped[str]=mapped_column(String(64), index=True)
    side: Mapped[str]=mapped_column(String(16))
    price: Mapped[float|None]=mapped_column(Float, nullable=True)
    quantity: Mapped[int|None]=mapped_column(Integer, nullable=True)
    status: Mapped[str|None]=mapped_column(String(32), nullable=True)
    ts: Mapped[datetime]=mapped_column(DateTime, default=datetime.utcnow)

class AIDecision(Base):
    __tablename__='ai_decisions'
    id: Mapped[int]=mapped_column(Integer, primary_key=True)
    isin: Mapped[str]=mapped_column(String(64), index=True)
    decision: Mapped[str]=mapped_column(String(32))
    score: Mapped[float|None]=mapped_column(Float, nullable=True)
    pd: Mapped[float|None]=mapped_column(Float, nullable=True)
    explanation: Mapped[str|None]=mapped_column(Text, nullable=True)
    model_version: Mapped[str|None]=mapped_column(String(128), nullable=True)
    ts: Mapped[datetime]=mapped_column(DateTime, default=datetime.utcnow, index=True)

class MLFeature(Base):
    __tablename__='ml_features'
    id: Mapped[int]=mapped_column(Integer, primary_key=True)
    entity_id: Mapped[str]=mapped_column(String(128), index=True)
    feature_set: Mapped[str]=mapped_column(String(128), index=True)
    payload: Mapped[str]=mapped_column(Text)
    ts: Mapped[datetime]=mapped_column(DateTime, default=datetime.utcnow, index=True)

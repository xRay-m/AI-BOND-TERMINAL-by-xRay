import os
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from .models import Base

URL=os.getenv('POSTGRES_URL','postgresql://terminal:terminal@localhost:5432/bond_terminal')
# Development/test fallback only when psycopg2 is unavailable. Production keeps PostgreSQL.
if URL.startswith('postgresql'):
    try: import psycopg2  # noqa: F401
    except Exception:
        URL='sqlite:///runtime/cache/local_fallback.db'
engine=create_engine(URL,pool_pre_ping=True,future=True)
SessionLocal=sessionmaker(bind=engine,expire_on_commit=False)

def init_db(): Base.metadata.create_all(engine)
def ping():
    with engine.connect() as c: c.execute(text('SELECT 1'))
    return True

import numpy as np,pandas as pd
from dataclasses import dataclass
@dataclass
class BacktestResult: equity:pd.Series;trades:pd.DataFrame;metrics:dict
def backtest(df,signal_col='signal',initial=100000,fee=.003,slippage=.001):
    d=df.copy().sort_values('date').reset_index(drop=True);d['ret']=d['close'].pct_change().fillna(0);sig=pd.to_numeric(d[signal_col],errors='coerce').fillna(0).clip(-1,1);pos=sig.shift(1).fillna(0);turnover=pos.diff().abs().fillna(pos.abs());strat=pos*d['ret']-turnover*(fee+slippage);equity=initial*(1+strat).cumprod();peak=equity.cummax();dd=equity/peak-1
    trades=d.loc[turnover>0,['date','close',signal_col]].copy();trades['side']='CHANGE';metrics={'initial':initial,'final':float(equity.iloc[-1]),'return_pct':float((equity.iloc[-1]/initial-1)*100),'max_drawdown_pct':float(dd.min()*100),'volatility_pct':float(strat.std()*np.sqrt(252)*100),'sharpe':float(strat.mean()/strat.std()*np.sqrt(252)) if strat.std()>0 else 0,'trades':int((turnover>0).sum())};return BacktestResult(equity,trades,metrics)
def walk_forward(df,train_days=252,test_days=63,step_days=63,strategy_fn=None):
    d=df.sort_values('date').reset_index(drop=True);results=[]
    for start in range(0,max(0,len(d)-train_days-test_days+1),step_days):
        train=d.iloc[start:start+train_days];test=d.iloc[start+train_days:start+train_days+test_days]
        if len(test)<test_days:break
        signal_fn=strategy_fn(train) if strategy_fn else lambda x:np.where(x['close'].pct_change().fillna(0)>0,1,-1)
        t=test.copy();t['signal']=signal_fn(t);r=backtest(t,'signal');results.append({'train_start':train.date.iloc[0],'test_start':test.date.iloc[0],**r.metrics})
    return pd.DataFrame(results),[]
def monte_carlo(returns,paths=5000,horizon=252,seed=42):
    rng=np.random.default_rng(seed);r=np.asarray(returns);sims=rng.choice(r,size=(paths,horizon),replace=True);terminal=np.exp(np.log1p(sims).sum(axis=1));return {'p05':float(np.quantile(terminal,.05)-1),'median':float(np.median(terminal)-1),'p95':float(np.quantile(terminal,.95)-1)}

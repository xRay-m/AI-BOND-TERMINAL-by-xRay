import pandas as pd, numpy as np
from backtesting.engine import backtest
from strategy.manager import evaluate_strategy

def run_strategy_backtest(df,strategy,initial=100000,fee=.003,slippage=.001):
    d=df.copy().sort_values('date').reset_index(drop=True)
    rows=[]
    for _,r in d.iterrows():
        bond={k:r.get(k) for k in ['price_pct','ytm_pct','pd','volume_rub']}
        result=evaluate_strategy(strategy,bond)
        rows.append(1 if result['action']=='BUY' else -1 if result['action']=='SELL' else 0)
    d['signal']=rows
    return backtest(d,'signal',initial=initial,fee=fee,slippage=slippage)

import os, time
class LiveGuard:
    def __init__(self): self.enabled=os.getenv('LIVE_ENABLED','false').lower()=='true'; self.kill=False
    def authorize(self, typed, instrument, side, qty, price, risk_passed):
        if self.kill: return False,'KILL SWITCH ACTIVE'
        if not self.enabled: return False,'LIVE_ENABLED=false'
        if not risk_passed: return False,'RISK CHECK FAILED'
        expected=f'LIVE {side} {instrument} {qty} {price}'
        return typed.strip()==expected, expected
    def kill_switch(self): self.kill=True

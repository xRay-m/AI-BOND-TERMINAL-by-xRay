param([string]$OutputDir=".\backups")
New-Item -ItemType Directory -Force $OutputDir | Out-Null
$stamp=Get-Date -Format "yyyyMMdd_HHmmss"
$container=(docker ps --filter "ancestor=postgres:16" --format "{{.ID}}" | Select-Object -First 1)
if (-not $container) { throw "PostgreSQL container not found" }
docker exec $container pg_dump -U terminal -d bond_terminal -Fc | Set-Content -Encoding Byte "$OutputDir\bond_terminal_$stamp.dump"
Write-Host "Backup created: $OutputDir\bond_terminal_$stamp.dump"

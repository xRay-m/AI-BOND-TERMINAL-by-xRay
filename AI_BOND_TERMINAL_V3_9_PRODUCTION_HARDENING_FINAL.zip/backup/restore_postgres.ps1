param([Parameter(Mandatory=$true)][string]$File)
$container=(docker ps --filter "ancestor=postgres:16" --format "{{.ID}}" | Select-Object -First 1)
if (-not $container) { throw "PostgreSQL container not found" }
Get-Content -Encoding Byte $File | docker exec -i $container pg_restore -U terminal -d bond_terminal --clean --if-exists
Write-Host "Restore complete"

from __future__ import annotations
from pathlib import Path
import json, joblib, numpy as np, pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, brier_score_loss
from ml.features import FEATURES, build_features

MODEL_SPECS={
 'pd_logistic': lambda: LogisticRegression(max_iter=3000,class_weight='balanced'),
 'pd_rf': lambda: RandomForestClassifier(n_estimators=300,max_depth=8,min_samples_leaf=4,class_weight='balanced_subsample',random_state=42,n_jobs=-1),
 'pd_hgb': lambda: HistGradientBoostingClassifier(max_iter=250,max_leaf_nodes=31,learning_rate=.05,l2_regularization=1.0,random_state=42),
}

def train_ensemble(csv_path, out_dir='models/ensemble', target='default_12m'):
    df=pd.read_csv(csv_path); d=build_features(df); y=d[target].astype(int); X=d[FEATURES].replace([np.inf,-np.inf],np.nan)
    Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,random_state=42,stratify=y)
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True); metrics={}
    for name,factory in MODEL_SPECS.items():
        model=Pipeline([('imputer',SimpleImputer(strategy='median',add_indicator=True)),('scale',StandardScaler()),('model',factory())]); model.fit(Xtr,ytr); p=model.predict_proba(Xte)[:,1]
        metrics[name]={'roc_auc':float(roc_auc_score(yte,p)),'brier':float(brier_score_loss(yte,p)),'rows_train':len(Xtr),'rows_test':len(Xte)}; joblib.dump({'model':model,'features':FEATURES,'target':target},out/f'{name}.joblib')
    (out/'metrics.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf-8')
    return metrics

def predict(df, model_dir='models/ensemble'):
    d=build_features(df); X=d[FEATURES].replace([np.inf,-np.inf],np.nan); ps=[]; loaded=[]
    for p in sorted(Path(model_dir).glob('*.joblib')):
        obj=joblib.load(p); ps.append(obj['model'].predict_proba(X)[:,1]); loaded.append(p.stem)
    if not ps:return np.full(len(d),np.nan),[]
    return np.mean(ps,axis=0),loaded

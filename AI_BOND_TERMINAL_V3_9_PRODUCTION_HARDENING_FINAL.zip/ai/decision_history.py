from database.db import SessionLocal
from database.models import AIDecision

def record(isin,decision,score=None,pd=None,explanation=None,model_version=None):
    with SessionLocal() as s:
        x=AIDecision(isin=isin,decision=decision,score=score,pd=pd,explanation=explanation,model_version=model_version); s.add(x); s.commit(); return x.id

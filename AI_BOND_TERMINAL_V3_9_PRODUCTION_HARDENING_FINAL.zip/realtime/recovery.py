from pathlib import Path
from datetime import datetime, timezone
import json, time
from oms.audit import AuditLog

class RecoveryCoordinator:
    def __init__(self,root='.'):
        self.root=Path(root); self.state_path=self.root/'runtime/recovery/state.json'; self.state_path.parent.mkdir(parents=True,exist_ok=True); self.audit=AuditLog()
    def checkpoint(self,component,**state):
        current=self.load(); current[component]={'ts':datetime.now(timezone.utc).isoformat(),**state}; self.state_path.write_text(json.dumps(current,ensure_ascii=False,indent=2),encoding='utf-8'); self.audit.write('RECOVERY_CHECKPOINT',component=component,state=state); return current
    def load(self):
        try:return json.loads(self.state_path.read_text(encoding='utf-8'))
        except:return {}
    def mark_failure(self,component,error): return self.checkpoint(component,status='FAILED',error=str(error))
    def mark_recovered(self,component,**state): return self.checkpoint(component,status='RECOVERED',**state)
    def recovery_report(self):
        s=self.load(); return {'ok':all(v.get('status')!='FAILED' for v in s.values()),'components':s}

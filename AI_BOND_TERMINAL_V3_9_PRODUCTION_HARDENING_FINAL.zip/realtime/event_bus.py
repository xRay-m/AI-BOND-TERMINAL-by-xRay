from __future__ import annotations
import json, uuid
from datetime import datetime, timezone
from realtime.redis_cache import publish, set_json

CHANNEL='ai_bond_terminal.events'

def emit(event_type,payload,stream='ai_bond_terminal_events'):
    event={'id':str(uuid.uuid4()),'ts':datetime.now(timezone.utc).isoformat(),'type':event_type,'payload':payload}
    publish(CHANNEL,event,stream=stream); set_json('event/last',event,ttl=300); return event

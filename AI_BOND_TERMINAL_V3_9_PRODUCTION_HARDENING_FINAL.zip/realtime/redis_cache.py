import os,json
from pathlib import Path
try: import redis
except Exception: redis=None
ROOT=Path(__file__).resolve().parents[1]; FALLBACK=ROOT/'runtime'/'cache'; FALLBACK.mkdir(parents=True,exist_ok=True)
client=redis.Redis.from_url(os.getenv('REDIS_URL','redis://localhost:6379/0'),decode_responses=True) if redis else None

def ping():
    try:return bool(client and client.ping())
    except Exception:return False

def set_json(key,value,ttl=120):
    payload=json.dumps(value,ensure_ascii=False,default=str)
    try:
        if client: client.setex(key,ttl,payload); return 'redis'
    except Exception: pass
    (FALLBACK/f'{key.replace("/","_")}.json').write_text(payload,encoding='utf-8'); return 'file'

def get_json(key):
    try:
        if client:
            v=client.get(key)
            if v:return json.loads(v)
    except Exception: pass
    p=FALLBACK/f'{key.replace("/","_")}.json'; return json.loads(p.read_text(encoding='utf-8')) if p.exists() else None

def publish(channel,value,stream='ai_bond_terminal_events'):
    raw=json.dumps(value,ensure_ascii=False,default=str)
    try:
        if client:
            client.publish(channel,raw)
            try: client.xadd(stream,{'payload':raw},maxlen=10000,approximate=True)
            except Exception: pass
            return 1
    except Exception: pass
    p=FALLBACK/f'{stream}.jsonl'; p.open('a',encoding='utf8').write(raw+'\n'); return 0

def stream_read(stream='ai_bond_terminal_events',last_id='0-0',count=100):
    if not client: return []
    try:
        rows=client.xread({stream:last_id},count=count,block=100)
        return rows
    except Exception:return []

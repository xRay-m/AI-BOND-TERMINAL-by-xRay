import os, json
from pathlib import Path
from dotenv import load_dotenv

ROOT=Path(__file__).resolve().parents[1]
RUNTIME=ROOT/'runtime'
SETTINGS_FILE=ROOT/'config'/'settings.json'
ENV_FILE=ROOT/'.env.local'
DEFAULTS={
    # Broker / connectivity
    'TINVEST_MODE':'SANDBOX','TINVEST_TOKEN':'','TINVEST_ACCOUNT_ID':'','TINVEST_SANDBOX_ACCOUNT_NAME':'AI Bond Terminal Sandbox','LIVE_ENABLED':False,
    'TELEGRAM_BOT_TOKEN':'','TELEGRAM_CHAT_ID':'','MOEX_BASE_URL':'https://iss.moex.com/iss',
    # Risk / trading
    'MAX_ORDER_RUB':10000.0,'MAX_DAILY_RUB':30000.0,'MAX_POSITION_PCT':15.0,'MAX_PD':0.08,
    'ORDERBOOK_DEPTH':20,'MARKET_REFRESH_SEC':10,'AUTO_REFRESH_SEC':10,'AUTO_MAX_ORDERS_PER_DAY':5,
    'DEFAULT_LOTS':1,'PAPER_START_RUB':100000.0,'MAX_PRICE_PER_ORDER_RUB':10000.0,'MAX_PRICE_PER_DAY_RUB':30000.0,
    # Storage / cache
    'POSTGRES_URL':'postgresql://terminal:terminal@localhost:5432/bond_terminal','REDIS_URL':'redis://localhost:6379/0',
    'NEWS_RSS_URLS':'https://www.cbr.ru/rss/RssNews','CACHE_TTL_SEC':30,'CACHE_MAX_MB':512,
    # Execution
    'SLIPPAGE_BPS':10.0,'FEE_BPS':30.0,'ORDER_TIMEOUT_SEC':30,'CONFIRM_TIMEOUT_SEC':120,
    # ML / backtest
    'PD_MODEL_PATH':'models/pd_model.joblib','PD_TRAINING_FILE':'training/PD_training_dataset_RU_bonds_12000_PIPELINE_TEST.csv',
    'PD_TARGET':'default_12m','ML_TEST_SIZE':0.2,'ML_RANDOM_STATE':42,'ML_RETRAIN_ENABLED':True,
    'BACKTEST_INITIAL_CAPITAL':100000.0,'BACKTEST_COMMISSION_BPS':30.0,'BACKTEST_SLIPPAGE_BPS':10.0,
    # UI / monitoring
    'UI_THEME':'dark','UI_REFRESH_SEC':3,'ONE_CLICK_TRADING':False,'COMMAND_PALETTE':True,'MOBILE_UI':True,'AUTO_ALERTS_ENABLED':True,'LAYOUT_VERSION':1,'MONITOR_REFRESH_SEC':3,'LOG_LEVEL':'INFO','UI_MODE':'Pro','ONBOARDING_DONE':False,'WORKSPACE':'Default',
    # Feature switches: every major module can be independently enabled/disabled.
    'FEATURE_MOEX':True,'FEATURE_ORDERBOOK':True,'FEATURE_NEWS':True,'FEATURE_SQL':True,'FEATURE_REDIS':True,
    'FEATURE_ML':True,'FEATURE_BACKTEST':True,'FEATURE_OPTIMIZER':True,'FEATURE_RISK':True,'FEATURE_STRATEGY':True,
    'FEATURE_AUTONOMOUS':True,'FEATURE_TINVEST':True,'FEATURE_TELEGRAM':True,'FEATURE_AUDIT':True,
    'FEATURE_PAPER':True,'FEATURE_SANDBOX':True,'FEATURE_MONITORING':True,'FEATURE_TESTS':True,
    'FEATURE_HISTORICAL':True,'FEATURE_RETRAINING':True,'FEATURE_BACKUP':True,'FEATURE_LOAD_TESTS':True,
    'AUTO_TRADING_ENABLED':False,'SEMI_AUTO_ENABLED':True,'MANUAL_TRADING_ENABLED':True,'AUTO_TRADING_MODE':'SIGNAL_ONLY','AUTO_TRADING_STRATEGY':'conservative_buy','AUTO_TRADING_INSTRUMENT':'','AUTO_TRADING_LOTS':1,'AUTO_TRADING_NOMINAL':1000.0,'AUTO_TRADING_COOLDOWN_SEC':300,'AUTO_TRADING_MIN_SCORE':100.0,'AUTO_TRADING_MAX_ORDERS_DAY':3,'AUTO_LIVE_ARMED':False,'AUTO_ENGINE_MODE':'PAPER','AUTO_MIN_LIQUIDITY':55.0,'AUTO_MAX_SPREAD_BPS':150.0,'AUTO_TAKE_PROFIT_PCT':4.0,'AUTO_EXIT_LOSS_PCT':5.0,'AUTO_TIME_EXIT_DAYS':45,'AUTO_ORDER_TIMEOUT_SEC':30,'AUTO_FAILOVER_ENABLED':True,'AUTO_DUPLICATE_PROTECTION':True,'AUTO_WORKER_ENABLED':False,'TINVEST_E2E_INSTRUMENT_ID':'','MOEX_REAL_DATA_ENABLED':True,'MOEX_REAL_DATA_PATH':'runtime/market/moex_bonds_live.csv','ML_REAL_DATA_ONLY_FOR_PROD':True,'PRODUCTION_READINESS_REQUIRED':True,
}

NUMBER_FLOAT={'MAX_ORDER_RUB','MAX_DAILY_RUB','MAX_POSITION_PCT','MAX_PD','CACHE_TTL_SEC','CACHE_MAX_MB','SLIPPAGE_BPS','FEE_BPS','PAPER_START_RUB','MAX_PRICE_PER_ORDER_RUB','MAX_PRICE_PER_DAY_RUB','AUTO_TRADING_NOMINAL','AUTO_TRADING_MIN_SCORE','AUTO_MIN_LIQUIDITY','AUTO_MAX_SPREAD_BPS','AUTO_TAKE_PROFIT_PCT','AUTO_EXIT_LOSS_PCT','ML_TEST_SIZE','BACKTEST_INITIAL_CAPITAL','BACKTEST_COMMISSION_BPS','BACKTEST_SLIPPAGE_BPS'}
NUMBER_INT={'ORDERBOOK_DEPTH','MARKET_REFRESH_SEC','AUTO_REFRESH_SEC','AUTO_MAX_ORDERS_PER_DAY','DEFAULT_LOTS','AUTO_TRADING_LOTS','AUTO_TRADING_COOLDOWN_SEC','AUTO_TRADING_MAX_ORDERS_DAY','AUTO_TIME_EXIT_DAYS','AUTO_ORDER_TIMEOUT_SEC','ORDER_TIMEOUT_SEC','CONFIRM_TIMEOUT_SEC','ML_RANDOM_STATE','UI_REFRESH_SEC','MONITOR_REFRESH_SEC'}
BOOLS={'LIVE_ENABLED','ONBOARDING_DONE','ONE_CLICK_TRADING','COMMAND_PALETTE','MOBILE_UI','AUTO_ALERTS_ENABLED','ML_RETRAIN_ENABLED','AUTO_TRADING_ENABLED','AUTO_LIVE_ARMED','SEMI_AUTO_ENABLED','MANUAL_TRADING_ENABLED'} | {k for k in DEFAULTS if k.startswith('FEATURE_')}


def load_settings():
    load_dotenv(ENV_FILE,override=False)
    data=DEFAULTS.copy()
    if SETTINGS_FILE.exists():
        try: data.update(json.loads(SETTINGS_FILE.read_text(encoding='utf-8')))
        except Exception: pass
    # Environment values override persisted values, except empty secret envs.
    for k in DEFAULTS:
        if k in os.environ and os.environ[k] != '': data[k]=os.environ[k]
    for k in BOOLS:
        if isinstance(data.get(k),str): data[k]=data[k].lower() in ('1','true','yes','on')
    for k in NUMBER_FLOAT:
        try: data[k]=float(data[k])
        except Exception: pass
    for k in NUMBER_INT:
        try: data[k]=int(data[k])
        except Exception: pass
    return data


def save_settings(data):
    merged=DEFAULTS.copy(); merged.update(data)
    SETTINGS_FILE.parent.mkdir(parents=True,exist_ok=True)
    SETTINGS_FILE.write_text(json.dumps(merged,ensure_ascii=False,indent=2),encoding='utf-8')
    # Persistent cache snapshot used by the terminal even when .env is unavailable.
    ensure_runtime()
    (RUNTIME/'cache'/'settings_cache.json').write_text(json.dumps(merged,ensure_ascii=False,indent=2),encoding='utf-8')
    # Mirror config/secrets for modules that use environment variables.
    lines=[]
    for k,v in merged.items():
        if isinstance(v,bool): v='true' if v else 'false'
        lines.append(f'{k}={v}')
    ENV_FILE.write_text('\n'.join(lines)+'\n',encoding='utf-8')
    load_dotenv(ENV_FILE,override=True)
    return merged


def ensure_runtime():
    for p in [RUNTIME/'cache',RUNTIME/'exports',RUNTIME/'logs',RUNTIME/'audit',RUNTIME/'backtests',RUNTIME/'ml',RUNTIME/'market',RUNTIME/'tests',RUNTIME/'monitoring']:
        p.mkdir(parents=True,exist_ok=True)

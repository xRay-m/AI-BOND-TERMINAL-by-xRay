from __future__ import annotations
import json, uuid
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import pandas as pd
from trading.risk_gate import RiskGate
from trading.execution_journal import record
from strategy.quant_strategies import ensemble

@dataclass
class AutoConfig:
    mode:str='PAPER' # PAPER/SANDBOX/LIVE
    enabled:bool=False
    strategy_mode:str='ENSEMBLE'
    max_position_pct:float=10.0
    risk_per_trade_pct:float=1.0
    max_order_rub:float=10000.0
    max_daily_rub:float=30000.0
    min_score:float=70.0
    min_liquidity:float=55.0
    max_spread_bps:float=150.0
    max_pd:float=.08
    take_profit_pct:float=4.0
    exit_loss_pct:float=5.0
    time_exit_days:int=45
    order_timeout_sec:int=30
    max_orders_day:int=5
    cooldown_sec:int=300

class AutoEngine:
    def __init__(self, root, risk_limits):
        self.root=Path(root); self.path=self.root/'runtime'/'autotrading'/'engine_state.json'; self.path.parent.mkdir(parents=True,exist_ok=True)
        self.risk_limits=risk_limits; self.config=AutoConfig(); self.state=self._load()
    def _load(self):
        if not self.path.exists(): return {'seen':{},'positions':{},'orders':{},'last_cycle':None,'daily':{}}
        try:return json.loads(self.path.read_text(encoding='utf-8'))
        except:return {'seen':{},'positions':{},'orders':{},'last_cycle':None,'daily':{}}
    def save(self):self.path.write_text(json.dumps(self.state,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
    def duplicate_key(self, instrument, side, price, qty): return f'{instrument}|{side}|{round(float(price),4)}|{int(qty)}'
    def duplicate(self,instrument,side,price,qty):
        k=self.duplicate_key(instrument,side,price,qty); return k in self.state['seen']
    def mark_seen(self,instrument,side,price,qty,order_id=''):
        self.state['seen'][self.duplicate_key(instrument,side,price,qty)]={'ts':datetime.now(timezone.utc).isoformat(),'order_id':order_id}; self.save()
    def position_size(self, portfolio_value, price_pct, nominal=1000, liquidity=100, pd=.05, current_position=0):
        risk_budget=max(0,portfolio_value*self.config.risk_per_trade_pct/100)
        max_pos=max(0,portfolio_value*self.config.max_position_pct/100-current_position)
        risk_factor=max(.15,min(1.0,1-float(pd)/max(self.config.max_pd,.0001)))
        liq_factor=max(.25,min(1.0,float(liquidity)/100))
        budget=min(self.config.max_order_rub,max_pos,risk_budget*10*risk_factor*liq_factor)
        lot_value=max(.01,float(price_pct)/100*float(nominal)); lots=max(0,int(budget//lot_value))
        return {'lots':lots,'budget_rub':lots*lot_value,'lot_value_rub':lot_value,'risk_factor':risk_factor,'liquidity_factor':liq_factor}
    def scan(self, df, selected=None):
        d=df.copy();
        if d.empty:return d
        d=ensemble(d,selected)
        d['auto_eligible']=(d['strategy_ensemble_score']>=self.config.min_score)&(d.get('liquidity_score',0)>=self.config.min_liquidity)&(d.get('spread_bps',0)<=self.config.max_spread_bps)&(d.get('pd',0)<=self.config.max_pd)
        return d.sort_values(['auto_eligible','strategy_ensemble_score'],ascending=[False,False])
    def exits(self, positions_df, prices):
        rows=[]; now=pd.Timestamp.utcnow().tz_localize(None)
        for _,r in positions_df.iterrows():
            inst=str(r.get('instrument_id',r.get('SECID',''))); entry=float(r.get('entry_price_pct',r.get('price_pct',100)) or 100); cur=float(prices.get(inst,r.get('price_pct',entry)) or entry)
            pnl=(cur-entry)/entry*100; opened=pd.to_datetime(r.get('opened_at'),errors='coerce'); age=(now-opened).days if pd.notna(opened) else 0
            action='HOLD'; reason=''
            if pnl>=self.config.take_profit_pct: action='SELL'; reason='TAKE_PROFIT'
            elif pnl<=-self.config.exit_loss_pct: action='SELL'; reason='RISK_EXIT'
            elif age>=self.config.time_exit_days: action='SELL'; reason='TIME_EXIT'
            rows.append({'instrument_id':inst,'action':action,'reason':reason,'pnl_pct':pnl,'age_days':age})
        return pd.DataFrame(rows)

class PaperBroker:
    def __init__(self, root, capital=100000):
        self.root=Path(root); self.path=self.root/'runtime'/'paper'/'account.json'; self.path.parent.mkdir(parents=True,exist_ok=True)
        if self.path.exists():
            self.state=json.loads(self.path.read_text(encoding='utf-8'))
        else:self.state={'cash':float(capital),'positions':{},'orders':{},'trades':[]}; self.save()
    def save(self):self.path.write_text(json.dumps(self.state,ensure_ascii=False,indent=2),encoding='utf-8')
    def submit(self, instrument, side, lots, price_pct, nominal=1000):
        value=float(lots)*float(price_pct)/100*float(nominal); oid='PAPER-'+uuid.uuid4().hex[:12]
        if side=='BUY' and value>self.state['cash']: raise ValueError('Недостаточно PAPER cash')
        pos=self.state['positions'].setdefault(instrument,{'lots':0,'avg_price':0})
        if side=='BUY':
            new=pos['lots']+lots; pos['avg_price']=(pos['avg_price']*pos['lots']+price_pct*lots)/max(new,1); pos['lots']=new; self.state['cash']-=value
        else:
            sell=min(lots,pos['lots']); pos['lots']-=sell; self.state['cash']+=sell*float(price_pct)/100*float(nominal)
        self.state['orders'][oid]={'order_id':oid,'instrument':instrument,'side':side,'lots':lots,'price_pct':price_pct,'status':'FILLED','ts':datetime.now(timezone.utc).isoformat()}; self.state['trades'].append(self.state['orders'][oid]); self.save(); return self.state['orders'][oid]

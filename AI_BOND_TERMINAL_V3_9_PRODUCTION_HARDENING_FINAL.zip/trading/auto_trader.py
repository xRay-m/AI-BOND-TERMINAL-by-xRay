from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from trading.execution_journal import record as execution_record
from trading.risk_gate import RiskGate, RiskDecision


AUTO_PRESETS = {
    "conservative_buy": {
        "name": "Консервативная покупка",
        "action": "BUY",
        "rules": [
            ("price_pct", "<=", 100.0),
            ("ytm_pct", ">=", 18.0),
            ("pd", "<=", 0.08),
        ],
    },
    "discount_yield": {
        "name": "Дисконт + доходность",
        "action": "BUY",
        "rules": [
            ("price_pct", "<", 98.0),
            ("ytm_pct", ">=", 20.0),
            ("pd", "<=", 0.08),
        ],
    },
    "risk_exit": {
        "name": "Выход по риску",
        "action": "SELL",
        "rules": [
            ("pd", ">", 0.15),
        ],
    },
}


@dataclass
class AutoState:
    enabled: bool = False
    armed: bool = False
    mode: str = "SIGNAL_ONLY"  # SIGNAL_ONLY / SEMI_AUTO / AUTO
    strategy: str = "conservative_buy"
    instrument_id: str = ""
    lots: int = 1
    nominal: float = 1000.0
    cooldown_sec: int = 300
    max_orders_day: int = 3
    min_score: float = 100.0
    orders_today: int = 0
    day: str = ""
    last_action_at: str = ""
    last_signal: str = "HOLD"
    last_reason: str = ""
    last_order_id: str = ""


class AutoTrader:
    """Simple, stateful automatic bond trader.

    The engine deliberately separates signal generation, risk checks and execution.
    It never bypasses RiskGate/Trading Halt and uses a persisted state file so a
    Streamlit rerun cannot accidentally duplicate an order.
    """

    def __init__(self, root: str | Path, risk_limits: Any):
        self.root = Path(root)
        self.path = self.root / "runtime" / "autotrading" / "state.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.limits = risk_limits
        self.state = self._load()
        self._roll_day()

    def _load(self) -> AutoState:
        if not self.path.exists():
            return AutoState(day=self._today())
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            allowed = {f.name for f in AutoState.__dataclass_fields__.values()}
            return AutoState(**{k: v for k, v in data.items() if k in allowed})
        except Exception:
            return AutoState(day=self._today())

    def save(self) -> AutoState:
        self.path.write_text(json.dumps(asdict(self.state), ensure_ascii=False, indent=2), encoding="utf-8")
        return self.state

    @staticmethod
    def _today() -> str:
        return datetime.now(timezone.utc).date().isoformat()

    def _roll_day(self) -> None:
        today = self._today()
        if self.state.day != today:
            self.state.day = today
            self.state.orders_today = 0
            self.save()

    def configure(self, **kwargs: Any) -> AutoState:
        for key, value in kwargs.items():
            if hasattr(self.state, key):
                setattr(self.state, key, value)
        self._roll_day()
        return self.save()

    def start(self) -> AutoState:
        self.state.enabled = True
        self.state.armed = True
        self.state.last_reason = "Автоторговля запущена"
        execution_record("AUTO_TRADING_STARTED", mode=self.state.mode, strategy=self.state.strategy,
                         instrument=self.state.instrument_id)
        return self.save()

    def stop(self, reason: str = "operator") -> AutoState:
        self.state.enabled = False
        self.state.armed = False
        self.state.last_reason = reason
        execution_record("AUTO_TRADING_STOPPED", reason=reason)
        return self.save()

    @staticmethod
    def _compare(value: float, op: str, target: float) -> bool:
        return {"<": value < target, "<=": value <= target, ">": value > target,
                ">=": value >= target, "==": value == target}.get(op, False)

    def signal(self, market: dict[str, float]) -> dict[str, Any]:
        preset = AUTO_PRESETS.get(self.state.strategy)
        if not preset:
            return {"action": "HOLD", "score": 0, "passed": False, "reasons": ["Неизвестная стратегия"]}
        checks = []
        for field, op, target in preset["rules"]:
            value = float(market.get(field, float("nan")))
            ok = value == value and self._compare(value, op, float(target))
            checks.append({"field": field, "value": value, "operator": op, "target": target, "passed": ok})
        passed = all(x["passed"] for x in checks)
        action = preset["action"] if passed else "HOLD"
        score = 100.0 * sum(x["passed"] for x in checks) / max(1, len(checks))
        reasons = [f"{x['field']} {x['operator']} {x['target']} → {'PASS' if x['passed'] else 'FAIL'}" for x in checks]
        return {"action": action, "score": score, "passed": passed, "checks": checks, "reasons": reasons,
                "strategy_name": preset["name"]}

    def can_cycle(self) -> tuple[bool, str]:
        self._roll_day()
        if not self.state.enabled or not self.state.armed:
            return False, "Автоторговля выключена"
        if not self.state.instrument_id:
            return False, "Не выбран инструмент"
        if self.state.orders_today >= self.state.max_orders_day:
            return False, "Достигнут дневной лимит авто-заявок"
        if self.state.last_action_at:
            try:
                last = datetime.fromisoformat(self.state.last_action_at)
                age = (datetime.now(timezone.utc) - last).total_seconds()
                if age < self.state.cooldown_sec:
                    return False, f"Cooldown: ещё {int(self.state.cooldown_sec - age)} сек."
            except Exception:
                pass
        return True, "READY"

    def cycle(self, market: dict[str, float], portfolio_value: float, daily_used: float,
              issuer_exposure_pct: float, spread_pct: float, liquidity_score: float,
              executor: Callable[[str, int, float], dict[str, Any]],
              trading_allowed: bool = True) -> dict[str, Any]:
        self._roll_day()
        if not trading_allowed:
            self.state.last_reason = "Рынок/инструмент недоступен для торговли"
            self.save()
            return {"status": "BLOCK", "reason": self.state.last_reason}
        ok, reason = self.can_cycle()
        if not ok:
            return {"status": "WAIT", "reason": reason}

        signal = self.signal(market)
        self.state.last_signal = signal["action"]
        self.state.last_reason = "; ".join(signal.get("reasons", []))
        execution_record("AUTO_SIGNAL", instrument=self.state.instrument_id, strategy=self.state.strategy,
                         signal=signal, market=market)
        if signal["action"] == "HOLD" or signal["score"] < self.state.min_score:
            self.save()
            return {"status": "HOLD", **signal}

        price = float(market.get("execution_price", 0.0))
        amount = float(self.state.lots) * price * float(self.state.nominal) / 100.0
        position_after_pct = min(100.0, amount / max(1.0, portfolio_value) * 100.0)
        gate = RiskGate(self.limits)
        decision: RiskDecision = gate.evaluate(
            signal["action"], self.state.instrument_id, amount, portfolio_value, position_after_pct,
            float(market.get("pd", 1.0)), daily_used, float(spread_pct), float(liquidity_score),
            float(issuer_exposure_pct)
        )
        execution_record("AUTO_RISK_GATE", instrument=self.state.instrument_id,
                         side=signal["action"], amount_rub=amount, allowed=decision.allowed,
                         checks=decision.checks, reasons=decision.reasons)
        if not decision.allowed:
            self.state.last_reason = "Risk Gate: " + ", ".join(decision.reasons)
            self.save()
            return {"status": "RISK_BLOCK", "signal": signal, "risk": asdict(decision)}

        if self.state.mode == "SIGNAL_ONLY":
            self.save()
            return {"status": "SIGNAL", "signal": signal, "risk": asdict(decision)}
        if self.state.mode == "SEMI_AUTO":
            self.save()
            return {"status": "CONFIRM", "signal": signal, "risk": asdict(decision)}

        result = executor(signal["action"], self.state.lots, price)
        self.state.orders_today += 1
        self.state.last_action_at = datetime.now(timezone.utc).isoformat()
        self.state.last_order_id = str(result.get("orderId") or result.get("order_id") or result.get("orderRequestId") or "")
        self.state.last_reason = "Заявка отправлена"
        self.save()
        execution_record("AUTO_ORDER_SUBMITTED", instrument=self.state.instrument_id,
                         side=signal["action"], lots=self.state.lots, price=price,
                         order_id=self.state.last_order_id, response=result)
        return {"status": "SUBMITTED", "signal": signal, "risk": asdict(decision), "response": result}

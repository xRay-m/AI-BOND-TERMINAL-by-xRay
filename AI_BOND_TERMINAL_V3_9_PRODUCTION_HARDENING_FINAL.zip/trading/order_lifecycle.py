from __future__ import annotations
from datetime import datetime, timezone
from trading.execution_journal import record

TERMINAL={'FILLED','REJECTED','CANCELLED','EXPIRED'}

def age_seconds(ts):
    try:return max(0,(datetime.now(timezone.utc)-datetime.fromisoformat(str(ts).replace('Z','+00:00'))).total_seconds())
    except:return 0

def inspect_orders(records, timeout_sec=30):
    out=[]
    for r in records:
        status=str(r.get('status',r.get('executionReportStatus',''))).upper()
        if status in TERMINAL: continue
        age=age_seconds(r.get('ts') or r.get('updated_at') or r.get('created_at'))
        if age>=timeout_sec:
            item={'order_id':r.get('order_id') or r.get('broker_order_id'),'instrument':r.get('instrument') or r.get('instrument_id'),'age_sec':age,'action':'CANCEL_OR_REPRICE','status':status}
            out.append(item); record('STALE_ORDER_DETECTED',**item)
    return out

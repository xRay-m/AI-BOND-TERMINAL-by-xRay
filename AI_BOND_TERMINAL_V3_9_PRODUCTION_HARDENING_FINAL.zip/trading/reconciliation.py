from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import json
from pathlib import Path

@dataclass
class ReconciliationResult:
    status: str
    checks: list
    critical: bool
    timestamp: str
    halt_reason: str = ''


def _num(v):
    try:
        if isinstance(v,dict): return float(v.get('units',0))+float(v.get('nano',0))/1e9
        return float(v)
    except Exception:return 0.0

def reconcile(local, broker, tolerances=None):
    tolerances=tolerances or {'cash':1.0,'portfolio':2.0,'position_lots':0.0,'orders':0.0}
    checks=[]
    def add(name,l,b,tol):
        diff=abs(l-b); ok=diff<=tol; checks.append({'check':name,'local':l,'broker':b,'difference':diff,'tolerance':tol,'status':'PASS' if ok else 'FAIL'})
    add('cash',_num(local.get('cash',0)),_num(broker.get('cash',0)),tolerances['cash'])
    add('portfolio',_num(local.get('portfolio',0)),_num(broker.get('portfolio',0)),tolerances['portfolio'])
    lp={str(x.get('instrument_id') or x.get('figi') or x.get('instrumentId')):_num(x.get('quantity',x.get('lots',0))) for x in local.get('positions',[])}
    bp={str(x.get('instrument_id') or x.get('figi') or x.get('instrumentId')):_num(x.get('quantity',x.get('lots',0))) for x in broker.get('positions',[])}
    for k in sorted(set(lp)|set(bp)): add(f'position:{k}',lp.get(k,0),bp.get(k,0),tolerances['position_lots'])
    add('orders_count',len(local.get('orders',[])),len(broker.get('orders',[])),tolerances['orders'])
    critical=any(x['status']=='FAIL' for x in checks)
    return ReconciliationResult('CRITICAL' if critical else 'PASS',checks,critical,datetime.now(timezone.utc).isoformat(),'Local/Broker mismatch' if critical else '')

def load_halt(path='runtime/risk/trading_halt.json'):
    p=Path(path)
    if not p.exists(): return {'halted':False}
    try:return json.loads(p.read_text(encoding='utf-8'))
    except:return {'halted':False}

import json, uuid
from datetime import datetime, timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PATH=ROOT/'runtime'/'trading'/'execution_journal.jsonl'
PATH.parent.mkdir(parents=True,exist_ok=True)

def record(event, **data):
    row={'id':uuid.uuid4().hex,'ts':datetime.now(timezone.utc).isoformat(),'event':event,**data}
    with PATH.open('a',encoding='utf-8') as f:f.write(json.dumps(row,ensure_ascii=False,default=str)+'\n')
    return row

def read(limit=500):
    if not PATH.exists(): return []
    out=[]
    for line in PATH.read_text(encoding='utf-8').splitlines()[-limit:]:
        try:out.append(json.loads(line))
        except:pass
    return list(reversed(out))

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
import json

@dataclass
class RiskDecision:
    allowed: bool
    checks: dict
    reasons: list
    timestamp: str
    action: str
    amount_rub: float
    instrument: str

class RiskGate:
    def __init__(self, limits, halt_path='runtime/risk/trading_halt.json'):
        self.limits=limits
        self.halt_path=Path(halt_path)
        self.halt_path.parent.mkdir(parents=True,exist_ok=True)
    def is_halted(self):
        if not self.halt_path.exists(): return False
        try: return bool(json.loads(self.halt_path.read_text(encoding='utf-8')).get('halted'))
        except Exception: return False
    def halt(self, reason, details=None):
        payload={'halted':True,'reason':reason,'details':details or {},'ts':datetime.now(timezone.utc).isoformat()}
        self.halt_path.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8'); return payload
    def resume(self, operator='manual'):
        payload={'halted':False,'reason':'manual_resume','operator':operator,'ts':datetime.now(timezone.utc).isoformat()}
        self.halt_path.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8'); return payload
    def evaluate(self, action, instrument, amount_rub, portfolio_value, position_after_pct, pd_prob, daily_used,
                 spread_pct=0.0, liquidity_score=100.0, issuer_exposure_pct=0.0, max_issuer_pct=30.0):
        checks={
            'trading_halt_clear': not self.is_halted(),
            'order_limit': amount_rub <= self.limits.max_order_rub,
            'position_limit': position_after_pct <= self.limits.max_position_pct,
            'daily_limit': daily_used + amount_rub <= self.limits.max_daily_rub,
            'pd_limit': (str(action).upper() == 'SELL') or (pd_prob <= self.limits.max_pd),
            'spread_ok': spread_pct <= 3.0,
            'liquidity_ok': liquidity_score >= 25.0,
            'issuer_concentration_ok': issuer_exposure_pct <= max_issuer_pct,
            'portfolio_value_valid': portfolio_value > 0,
        }
        reasons=[k for k,v in checks.items() if not v]
        return RiskDecision(all(checks.values()),checks,reasons,datetime.now(timezone.utc).isoformat(),action,amount_rub,instrument)
    def gate(self, **kwargs): return self.evaluate(**kwargs)
    def serialize(self, decision): return asdict(decision)

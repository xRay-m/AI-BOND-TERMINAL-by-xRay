from __future__ import annotations
import math, time

def limit_price(best_bid, best_ask, side, aggression=0.5):
    bid=float(best_bid or 0); ask=float(best_ask or bid)
    if not bid:return ask
    if not ask:return bid
    return bid+(ask-bid)*float(max(0,min(1,aggression))) if side=='BUY' else ask-(ask-bid)*float(max(0,min(1,aggression)))

def twap_slices(total_lots, slices=5):
    total=int(total_lots); n=max(1,min(int(slices),total)); base=total//n; rem=total%n
    return [base+(1 if i<rem else 0) for i in range(n)]

def execution_plan(total_lots, side, best_bid, best_ask, algo='LIMIT', slices=5):
    if algo=='TWAP':
        return [{'slice':i+1,'lots':q,'price':limit_price(best_bid,best_ask,side,0.5)} for i,q in enumerate(twap_slices(total_lots,slices))]
    return [{'slice':1,'lots':int(total_lots),'price':limit_price(best_bid,best_ask,side,0.5)}]

from dataclasses import dataclass
@dataclass
class RiskLimits:
    max_order_rub: float=10000
    max_position_pct: float=15
    max_daily_rub: float=30000
    max_pd: float=.08
class RiskEngine:
    def __init__(self,limits=None): self.limits=limits or RiskLimits()
    def check(self, amount, portfolio_value, position_after_pct, pd_prob, daily_used):
        checks={
          'order_limit': amount<=self.limits.max_order_rub,
          'position_limit': position_after_pct<=self.limits.max_position_pct,
          'daily_limit': daily_used+amount<=self.limits.max_daily_rub,
          'pd_limit': pd_prob<=self.limits.max_pd}
        return checks, all(checks.values())

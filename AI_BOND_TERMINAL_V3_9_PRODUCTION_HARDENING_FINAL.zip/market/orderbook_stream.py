class OrderBookStream:
    """Adapter for the current T-Invest SDK streaming implementation.
    subscribe_fn(instrument_ids, callback) must create the official market-data subscription.
    """
    def __init__(self,subscribe_fn,on_update=None): self.subscribe_fn=subscribe_fn; self.on_update=on_update; self.running=False
    def start(self,instrument_ids): self.running=True; return self.subscribe_fn(instrument_ids,self._handle)
    def _handle(self,update):
        if self.on_update: self.on_update(update)
    def stop(self): self.running=False

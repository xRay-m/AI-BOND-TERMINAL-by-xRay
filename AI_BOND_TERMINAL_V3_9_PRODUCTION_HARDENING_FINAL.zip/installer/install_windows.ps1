$ErrorActionPreference='Stop'
Write-Host 'V3.1 PRODUCTION HARDENING installer'
if (-not (Get-Command python -ErrorAction SilentlyContinue)) { throw 'Python 3.11/3.12 is required' }
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) { throw 'Docker Desktop is required' }
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
if (-not (Test-Path .env)) { Copy-Item .env.example .env }
Write-Host 'Dependencies installed. Edit .env, then run docker compose up -d and scripts/init_data_engine.py.'

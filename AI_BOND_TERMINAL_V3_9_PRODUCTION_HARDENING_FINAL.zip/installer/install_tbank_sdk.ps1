$ErrorActionPreference='Stop'
.\.venv\Scripts\python.exe -m pip install t-tech-investments --index-url https://opensource.tbank.ru/api/v4/projects/238/packages/pypi/simple
Write-Host 'T-Bank Python SDK installed.'

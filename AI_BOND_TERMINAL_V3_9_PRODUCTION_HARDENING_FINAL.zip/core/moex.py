import requests, pandas as pd

class MOEXClient:
    def __init__(self, base_url='https://iss.moex.com/iss', timeout=20):
        self.base_url=base_url.rstrip('/'); self.timeout=timeout
    def _get(self,path,params=None):
        r=requests.get(self.base_url+path,params=params or {},timeout=self.timeout,headers={'User-Agent':'AI-Bond-Terminal/3.1'})
        r.raise_for_status(); return r.json()
    @staticmethod
    def _block(js,name):
        b=js.get(name,{})
        return pd.DataFrame(b.get('data',[]),columns=b.get('columns',[]))
    def bonds(self,start=0,limit=500):
        js=self._get('/engines/stock/markets/bonds/securities.json',{'iss.meta':'off','start':start,'limit':limit})
        sec=self._block(js,'securities'); md=self._block(js,'marketdata')
        if sec.empty:return sec
        if not md.empty and 'SECID' in md.columns and 'SECID' in sec.columns: sec=sec.merge(md,on='SECID',how='left',suffixes=('','_md'))
        return sec
    def security(self,secid):
        js=self._get(f'/engines/stock/markets/bonds/securities/{secid}.json',{'iss.meta':'off'})
        return self._block(js,'securities'),self._block(js,'marketdata')
    def candles(self,secid,interval=24,start=None,end=None):
        p={'iss.meta':'off','interval':interval};
        if start:p['from']=start
        if end:p['till']=end
        return self._block(self._get(f'/engines/stock/markets/bonds/securities/{secid}/candles.json',p),'candles')
    def history(self,secid,start=None,end=None,limit=1000):
        p={'iss.meta':'off','limit':limit};
        if start:p['from']=start
        if end:p['till']=end
        return self._block(self._get(f'/history/engines/stock/markets/bonds/securities/{secid}.json',p),'history')
    def orderbook(self,secid,depth=20):
        js=self._get('/engines/stock/markets/bonds/orderbook.json',{'iss.meta':'off','securities':secid,'depth':int(depth)})
        for name in ('orderbook','orders','marketdata'):
            d=self._block(js,name)
            if not d.empty:return d
        return pd.DataFrame()
    def last_trade_price(self,secid):
        sec,md=self.security(secid)
        d=md if not md.empty else sec
        for c in ('LAST','LASTVALUE','MARKETPRICE','PREVPRICE'):
            if c in d.columns:
                x=pd.to_numeric(d[c],errors='coerce').dropna()
                if len(x):return float(x.iloc[0])
        return None

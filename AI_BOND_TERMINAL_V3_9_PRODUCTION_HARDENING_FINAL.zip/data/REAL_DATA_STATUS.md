# Реальные данные — статус V3.9

Источник production market data: официальный MOEX ISS (`https://iss.moex.com/iss`).

В архиве есть production collector и команды загрузки, но **локальная среда сборки не имела DNS/network-доступа к `iss.moex.com`**, поэтому я не стал подменять реальные рыночные данные синтетикой и не маркирую существующий synthetic dataset как real.

После запуска на ПК с интернетом:

```text
python scripts/ingest_moex_real.py
python scripts/build_real_ml_dataset.py --secids <SECID1,SECID2,...> --board TQCB --from-date 2018-01-01
python scripts/train_real_market_ml.py
```

Для PD необходима отдельная подтверждённая разметка дефолтов. Цена/объём MOEX сами по себе не являются корректной разметкой default_12m.

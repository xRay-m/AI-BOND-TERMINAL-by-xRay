from __future__ import annotations
from pathlib import Path
import time, requests, pandas as pd

class MoexHistoryLoader:
    BASE='https://iss.moex.com/iss'
    def __init__(self, cache_dir='data/moex_cache', timeout=20):
        self.cache=Path(cache_dir); self.cache.mkdir(parents=True,exist_ok=True); self.timeout=timeout
    def candles(self, secid, engine='stock', market='bonds', board='TQCB', date_from=None, date_till=None, interval=24):
        url=f'{self.BASE}/engines/{engine}/markets/{market}/boards/{board}/securities/{secid}/candles.json'
        params={'interval':interval};
        if date_from: params['from']=date_from
        if date_till: params['till']=date_till
        rows=[]; start=0
        while True:
            p=dict(params,start=start); r=requests.get(url,params=p,timeout=self.timeout); r.raise_for_status(); block=r.json().get('candles',{})
            data=block.get('data',[]); cols=block.get('columns',[])
            if not data: break
            rows.extend(data)
            if len(data)<100: break
            start+=len(data); time.sleep(.05)
        return pd.DataFrame(rows,columns=cols)
    def save(self,df,path):
        p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
        df.to_parquet(p,index=False) if p.suffix=='.parquet' else df.to_csv(p,index=False)
        return p

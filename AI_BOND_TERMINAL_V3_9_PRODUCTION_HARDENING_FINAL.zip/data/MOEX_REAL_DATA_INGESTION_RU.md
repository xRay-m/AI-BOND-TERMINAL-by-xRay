# Реальный market-data ingestion

1. Получать текущий и исторический рынок через официальный MOEX ISS/исторические выгрузки.
2. Для стакана и Time & Sales использовать T-Invest MarketData.
3. Нормализовать всё в `data/ml_training_market.csv` по шаблону.
4. Для каждого ряда сохранять `data_source`, `observation_date` и идентификатор инструмента.
5. Не смешивать synthetic pipeline-test rows с production training rows.
6. Перед обучением выполнять time-based split / walk-forward.

Файл `ML_REAL_MARKET_TRAINING_TEMPLATE.xlsx` содержит таблицу и справочник полей.

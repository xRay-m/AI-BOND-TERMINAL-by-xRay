from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import time, requests, pandas as pd

class MOEXRealDataCollector:
    """Production-oriented MOEX ISS collector. ISS provides market, quote, trade and historical data."""
    def __init__(self,base='https://iss.moex.com/iss',timeout=30,retries=4): self.base=base.rstrip('/'); self.timeout=timeout; self.retries=retries
    def _get(self,url,params=None):
        last=None
        for i in range(self.retries):
            try:
                r=requests.get(url,params=params,timeout=self.timeout,headers={'User-Agent':'AI-BOND-TERMINAL/3.9'}); r.raise_for_status(); return r.json()
            except Exception as e: last=e; time.sleep(min(8,2**i))
        raise last
    @staticmethod
    def _frame(block):
        return pd.DataFrame(block.get('data',[]),columns=block.get('columns',[])) if block else pd.DataFrame()
    def bond_snapshot(self,limit=5000):
        rows=[]; start=0
        url=f'{self.base}/engines/stock/markets/bonds/securities.json'
        while start<limit:
            payload=self._get(url,{'start':start,'limit':min(100,limit-start),'iss.meta':'off'})
            sec=self._frame(payload.get('securities')); md=self._frame(payload.get('marketdata'))
            if sec.empty: break
            if not md.empty and 'SECID' in sec and 'SECID' in md: sec=sec.merge(md,on='SECID',how='left',suffixes=('','_MD'))
            rows.append(sec); start+=len(sec)
            if len(sec)<100: break
        return pd.concat(rows,ignore_index=True) if rows else pd.DataFrame()
    def history(self,secid,board='TQCB',date_from=None,date_till=None,limit=100000):
        url=f'{self.base}/history/engines/stock/markets/bonds/boards/{board}/securities/{secid}.json'
        rows=[]; start=0; params={'limit':100}
        if date_from: params['from']=date_from
        if date_till: params['till']=date_till
        while start<limit:
            params['start']=start; payload=self._get(url,params); frame=self._frame(payload.get('history'))
            if frame.empty: break
            rows.append(frame); start+=len(frame)
            if len(frame)<100: break
        return pd.concat(rows,ignore_index=True) if rows else pd.DataFrame()
    def export_snapshot(self,path='runtime/market/moex_bonds_live.csv'):
        p=Path(path); p.parent.mkdir(parents=True,exist_ok=True); d=self.bond_snapshot(); d.to_csv(p,index=False); return {'rows':len(d),'path':str(p),'source':'MOEX ISS','downloaded_at':datetime.now(timezone.utc).isoformat()}
